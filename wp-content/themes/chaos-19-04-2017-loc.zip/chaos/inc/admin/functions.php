<?php 
require get_template_directory() . '/inc/admin/menu-functions.php';
require get_template_directory() . '/inc/admin/team/pagination-functions.php';
require get_template_directory() . '/inc/admin/team/functions/ajax-functions.php';

require get_template_directory() . '/inc/admin/billing/functions.php';
require get_template_directory() . '/inc/admin/utility-manager/functions.php';



add_action( 'admin_enqueue_scripts', 'custom_wp_admin_scripts' );
function custom_wp_admin_scripts() {
  wp_enqueue_style( 'admin-style', get_template_directory_uri() . '/inc/admin/css/admincss.css' );

  wp_enqueue_style( 'src-select2', get_template_directory_uri() . '/inc/admin/js/select2/dist/css/select2.min.css' );  
  wp_enqueue_script( 'src-select2', get_template_directory_uri() . '/inc/admin/js/select2/dist/js/select2.full.min.js', array('jquery'), false, false );
  
  wp_enqueue_script( 'repeater', get_template_directory_uri() . '/inc/admin/js/jquery.repeater.js', array('jquery'), false, false );

  wp_enqueue_script('jquery-ui-datepicker');
  wp_enqueue_style('jquery-ui-css', 'http://code.jquery.com/ui/1.8.24/themes/blitzer/jquery-ui.css');
  

  wp_enqueue_script( 'ui-script',  get_template_directory_uri() . '/inc/admin/js/jquery-ui.js', array('jquery'), false, false );


  wp_enqueue_script( 'admin-script',  get_template_directory_uri() . '/inc/admin/js/script.js', array('jquery'), false, false );
  wp_localize_script( 'admin-script', 'frontendajax', array( 'ajaxurl' => admin_url( 'admin-ajax.php' )));
 

}

function searchPlayer($search = ''){

  global $wpdb;
  $customer_name = $_POST['search_key'];

  $member_table = $wpdb->prefix. 'chaos_members';
  $query = "SELECT * FROM {$member_table} WHERE  name LIKE '".$customer_name."%' AND active = 1";
  $data['items'] =  $wpdb->get_results( $query );
  echo json_encode($data);
  die();
}
add_action( 'wp_ajax_searchPlayer', 'searchPlayer' );
add_action( 'wp_ajax_nopriv_searchPlayer', 'searchPlayer' );

function getTeams(){

  global $wpdb;
  $football_team = $wpdb->prefix. 'chaos_football_team';
  $relation_team = $wpdb->prefix. 'chaos_football_team_relation';

  $query = "SELECT tot.*, SUM(tot.is_membar) as mem_count from (SELECT ft.id, ft.team_name, ft.active as team_active, (CASE WHEN ftr.active is NULL THEN 1 ELSE ftr.active END ) as relation_active, (CASE WHEN ftr.active is NULL THEN 0 ELSE 1 END ) as is_membar FROM ${football_team} ft LEFT JOIN ${relation_team} ftr ON ft.id = ftr.team_id ) tot WHERE tot.relation_active = 1 AND tot.team_active = 1 GROUP BY tot.id";
  $teams = $wpdb->get_results( $query );

  return $teams;

}

function get_team_detail($team_id = '') {

  global $wpdb;
  $football_team = $wpdb->prefix. 'chaos_football_team';
  $query = "SELECT * FROM ${football_team} WHERE active = 1 AND id=".$team_id;
  $data['team_data'] =  $wpdb->get_row( $query ) ;

  $data['members_data'] = false;
  if($data['team_data']) {
    $team_relation = $wpdb->prefix. 'chaos_football_team_relation';
    $chaos_members = $wpdb->prefix. 'chaos_members';

    $members_query = "SELECT m.id, m.name, m.phone FROM ${team_relation} tr JOIN ${chaos_members} m ON tr.member_id = m.id WHERE tr.active = 1 AND m.active = 1 AND tr.team_id = ${team_id}";
    $data['members_data'] =  $wpdb->get_results( $members_query );
  }
  return $data;
}


function getTournamentDetail($tournament_id = 0) {
  global $wpdb;
  $tournament_table = $wpdb->prefix. 'chaos_tournaments';
  $query = "SELECT * FROM ${tournament_table} WHERE active = 1 AND id=".$tournament_id;
  return $wpdb->get_row( $query );
}
function getTournamentTeams($tournament_id = 0, $active = 1) {
  global $wpdb;
  $tournament_teams_table = $wpdb->prefix. 'chaos_tournament_teams';
  $teams_table = $wpdb->prefix. 'chaos_football_team';
  if($active == 1) {
    $query = "SELECT tt.*, t.team_name FROM ${tournament_teams_table} as tt JOIN ${teams_table} as t ON tt.team_id = t.id WHERE tt.active = ${active} AND tt.tournament_id=".$tournament_id;
  } else {
    $query = "SELECT tt.*, t.team_name FROM ${tournament_teams_table} as tt JOIN ${teams_table} as t ON tt.team_id = t.id WHERE tt.tournament_id=".$tournament_id;
  }

  return $wpdb->get_results( $query, ARRAY_A );
}
function getTournamentSchedule($tournament_id = 0) {
  global $wpdb;
  $tournament_teams_table = $wpdb->prefix. 'chaos_tournament_schedule';
  $teams_table = $wpdb->prefix. 'chaos_football_team';
  $query = "SELECT *, (SELECT team_name from ${teams_table} as t WHERE t.id = ts.team1 ) as team1_name, (SELECT team_name from ${teams_table} as t WHERE t.id = ts.team2 ) as team2_name FROM ${tournament_teams_table} as ts WHERE active = 1 AND ts.tournament_id=".$tournament_id." ORDER BY ts.match_order ASC";

  return $wpdb->get_results( $query );
}


function getMatchDetails($match_id = 0){
  global $wpdb;
  $match_table = $wpdb->prefix. 'chaos_tournament_schedule';
  $team_table = $wpdb->prefix. 'chaos_football_team';

  $query = "SELECT *, (SELECT team_name from ${team_table} as t WHERE t.id = ts.team1 ) as team1_name, (SELECT team_name from ${team_table} as t WHERE t.id = ts.team2 ) as team2_name, (SELECT team_name from wp_chaos_football_team as t WHERE t.id = ts.winner ) as winner_team, (SELECT team_name from wp_chaos_football_team as t WHERE t.id = ts.loser ) as loser_team FROM ${match_table} as ts WHERE active = 1 AND ts.id=${match_id} ORDER BY ts.match_order ASC";
 
  return $wpdb->get_row( $query );
}


?>