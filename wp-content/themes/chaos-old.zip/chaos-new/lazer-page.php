<?php
/**
 * Template Name: Lazer Page
 *
 * This is the template that displays full width page without sidebar
 *
 * @package sparkling
 */

get_header(); ?>

<section class="ps-bg lazer-bg">
        <header id="home-lz">
            <section class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-3 col-sm-12 col-xs-6">
                        <div class="ps-logo">
                            <img src="<?php echo get_template_directory_uri() ?>/inc/img/logo.png" alt="" class="img-responsive">
                        </div>
                    </div>
                    <div class="col-lg-8 col-md-9 col-sm-12">
                        <nav class="navbar navbar-default">
                            <div class="container-fluid">
                                <!-- Brand and toggle get grouped for better mobile display -->
                                <div class="navbar-header">
                                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                                        <span class="sr-only">Toggle navigation</span>
                                        <span class="icon-bar"></span>
                                        <span class="icon-bar"></span>
                                        <span class="icon-bar"></span>                                    </button>
<!--                                    <a class="navbar-brand visible-xs" href="#">Menu</a>-->
                                </div><?php chaos_header_menu() ?>
                                <!-- Collect the nav links, forms, and other content for toggling -->
                                <!-- <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                                    <ul class="nav navbar-nav navbar-right">
                                        <li><a href="#home-lz" class="page-scroll">HOME</a></li>
                                        <li><a href="#about-lz" class="page-scroll">ABOUT</a></li>
                                        <li><a href="#lz-fac" class="page-scroll">FACILITIES</a></li>
                                        <li><a href="#lz-memb" class="page-scroll">MEMBERSHIP</a></li>
                                        <li><a href="#lz-winner" class="page-scroll">WINNER</a></li>
                                        <li><a href="#lz-contact" class="page-scroll">CONTACT</a></li>
                                    </ul>
                                </div> -->
                                <!-- /.navbar-collapse -->
                            </div>
                            <!-- /.container-fluid -->
                        </nav>
                    </div>
                    <div class="menu-bar">
                        <!--                        <i class="fa fa-bars" aria-hidden="true"></i>-->
                        <a id="menu-toggle" href="#" class="btn btn-primary btn-lg toggle"><i class="fa fa-chevron-down" aria-hidden="true"></i></a>
                        <div id="sidebar-wrapper">
                            <ul class="sidebar-nav">
                                <a id="menu-close" href="#" class="btn btn-default btn-lg pull-right toggle"><i class="glyphicon glyphicon-remove"></i></a>

                                <li class="sidebar-brand">
                                    <a href="index.html">Chaos</a>
                                </li>
                                <li>
                                    <a href="ps.html">Play Station</a>
                                </li>
                                <li>
                                    <a href="lazer.html">Lazer Tag</a>
                                </li>
                                <li>
                                    <a href="football.html">Fifa</a>
                                </li>
                                <div class="sm sm-mob visible-sm visible-xs">
                                    <i class="fa fa-facebook" aria-hidden="true"></i>
                                    <i class="fa fa-twitter" aria-hidden="true"></i>
                                    <i class="fa fa-google-plus" aria-hidden="true"></i>
                                </div>
                            </ul>

                        </div>
                    </div>
                </div>
            </section>
        </header>
        <section class="lz-banner">
            <div class="container-fluid">
                <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
                    <!-- Indicators -->
                    <ol class="carousel-indicators">
                        <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
                        <li data-target="#carousel-example-generic" data-slide-to="1"></li>
                        <li data-target="#carousel-example-generic" data-slide-to="2"></li>
                    </ol>

                    <!-- Wrapper for slides -->
                    <div class="carousel-inner" role="listbox">
                        <div class="item active">
                            <img src="<?php echo get_template_directory_uri() ?>/inc/img/lazer-banner.jpg" alt="">
                            <div class="carousel-caption">

                            </div>
                        </div>
                        <div class="item">
                            <img src="<?php echo get_template_directory_uri() ?>/inc/img/lazer-banner.jpg" alt="">
                            <div class="carousel-caption">

                            </div>
                        </div>

                    </div>

                    <!-- Controls -->
                    <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
                        <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                        <span class="sr-only">Previous</span>
                    </a>
                    <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
                        <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
                        <span class="sr-only">Next</span>
                    </a>
                </div>

            </div>
        </section>
        <section class="lazer-about postt" id="about-lz">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 col-md-8 col-sm-8">
                        <div class="joy-text">
                            <div class="lazer-title">
                                <h2>ABOUT<br><span>CHAOS</span></h2>
                            </div>
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages. Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
                            </p>
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                        </div>
                    </div>

                    <div class="col-md-4 col-sm-4 hidden-lg hidden-xs">
                        <div class="joy-img">
                            <img src="<?php echo get_template_directory_uri() ?>/inc/img/lazer-ab.png" alt="" class="img-responsive">
                        </div>
                    </div>

                </div>
            </div>
        </section>

        <section class="facility-lazer facility" id="lz-fac">
            <div class="container">
                <div class="fac-bg postt">
                    <div class="row">
                        <h2>FACILITIES</h2>
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                            <div class="row">
                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                                    <div class="facility-con" data-list="#facility1">
                                        <img src="<?php echo get_template_directory_uri() ?>/inc/img/test-1.jpg" alt="" class="img-responsive">
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                                    <div class="facility-con" data-list="#facility2">
                                        <img src="<?php echo get_template_directory_uri() ?>/inc/img/test-1.jpg" alt="" class="img-responsive">
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                                    <div class="facility-con" data-list="#facility3">
                                        <img src="<?php echo get_template_directory_uri() ?>/inc/img/test-1.jpg" alt="" class="img-responsive">
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                                    <div class="facility-con" data-list="#facility4">
                                        <img src="<?php echo get_template_directory_uri() ?>/inc/img/test-1.jpg" alt="" class="img-responsive">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-lg-offset-1 col-md-5 col-md-offset-1 col-sm-6 col-xs-12">
                            <div class="row face-list">
                                <div class="col-lg-12">
                                    <div class="face-content active" id="facility1">
                                        <img src="<?php echo get_template_directory_uri() ?>/inc/img/fac-2.jpg" alt="" class="img-responsive">
                                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the Lorem Ipsum has been the industry's standard dummy text ever since the standard dummy text ever since the</p>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="face-content" id="facility2">
                                        <img src="<?php echo get_template_directory_uri() ?>/inc/img/fac-3.jpg" alt="" class="img-responsive">
                                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the Lorem Ipsum has been the industry's standard dummy text ever since the</p>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="face-content" id="facility3">
                                        <img src="<?php echo get_template_directory_uri() ?>/inc/img/fac-2.jpg" alt="" class="img-responsive">
                                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the Lorem Ipsum has been the industry's standard dummy text ever since the standard dummy text ever since the</p>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="face-content" id="facility4">
                                        <img src="<?php echo get_template_directory_uri() ?>/inc/img/fac-3.jpg" alt="" class="img-responsive">
                                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the Lorem Ipsum has been the industry's standard dummy text ever since the</p>
                                    </div>
                                </div>
                            </div>

                        </div>
                        <div class="col-lg-10 col-md-12">
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the Lorem Ipsum has been the industry's standard dummy text ever since the</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="membership" id="lz-memb">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-md-12">
                        <div class="memb-text lazer-memb postt">
                            <h2>MEMBERSHIP</h2>
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the Lorem Ipsum has been the industry's standard dummy text ever since the</p>
                            <button><a href="">JOIN NOW</a></button>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <div class="winner" id="lz-winner">
            <section class="container">
                <div class="winner-bg postt">
                    <div class="row">
                        <h2>WINNERS</h2>
                        <div class="col-lg-4 col-md-4 col-sm-6">
                            <h3>WINNER<br>OF<br>THE WEEK</h3>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-6">
                            <img src="<?php echo get_template_directory_uri() ?>/inc/img/winner.png" alt="" class="img-responsive">
                        </div>
                        <div class="col-lg-3 col-lg-offset-1 col-md-4 col-sm-12">
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the Lorem Ipsum has been the industry's standard dummy text ever since the</p>
                            <button><a href="">JOIN NOW</a></button>
                        </div>
                    </div>
                </div>
            </section>
        </div>

        <section class="contact contact-lz" id="lz-contact">
            <section class="container">
                <div class="contact-bg postt">
                    <div class="row">
                        <div class="col-lg-12">
                            <h2>CONTACT US</h2>
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the</p>
                        </div>
                        <div class="col-lg-12">
                            <form class="form-inline">
                                <div class="form-group">

                                    <input type="text" class="form-control" id="exampleInputName2" placeholder="Name">
                                </div>
                                <div class="form-group">

                                    <input type="email" class="form-control" id="exampleInputEmail2" placeholder="Email">
                                </div>
                                <div class="form-group">

                                    <input type="tel" class="form-control" id="phone" placeholder="Phone">
                                </div>
                                <br>
                                <br>
                                <button type="submit" class="btn btn-default">Submit</button>
                            </form>
                        </div>
                        <div class="col-lg-12">
                            <div class="adres">
                                <div class="row">
                                    <div class="col-lg-3 col-md-3">
                                        <div class="adres-icon">
                                            <i class="fa fa-map-marker" aria-hidden="true"></i><span>Avvai Shanmugam Salai, Gopalapuram, Chennai, Tamil Nadu 600014</span>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-md-3">
                                        <div class="adres-icon">
                                            <i class="fa fa-phone" aria-hidden="true"></i><span>099401 40757</span>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-md-3">
                                        <div class="adres-icon">
                                            <i class="fa fa-envelope-o" aria-hidden="true"></i><span>chaos@gmail.com</span>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-md-3">
                                        <div class="sm-ps sm-lz">
                                            <i class="fa fa-facebook" aria-hidden="true"></i>
                                            <i class="fa fa-twitter" aria-hidden="true"></i>
                                            <i class="fa fa-google-plus" aria-hidden="true"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </section>
        </section>
        <footer>
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12">
                        <p>2016 All rights reserved. Developed by <a href="http://ajnainfotech.com" target="_blank">Ajna Infotech</a></p>
                    </div>
                </div>
            </div>
        </footer>
    </section>

<?php get_footer(); ?>
