<?php
/**
 * Template Name: New Page1
 * This is the template that displays full width page without sidebar
 *
 * @package sparkling
 */

get_header(); ?>