<?php 
require get_template_directory() . '/inc/admin/menu-functions.php';
require get_template_directory() . '/inc/admin/leagues/pagination-functions.php';
require get_template_directory() . '/inc/admin/leagues/functions/ajax-functions.php';
require get_template_directory() . '/inc/admin/chaos_members/functions/ajax-functions.php';
require get_template_directory() . '/inc/admin/chaos_members/pagination-functions.php';

add_action( 'admin_enqueue_scripts', 'custom_wp_admin_scripts' );
function custom_wp_admin_scripts() {
	wp_enqueue_style( 'admin-style', get_template_directory_uri() . '/inc/admin/css/admincss.css' );

	wp_enqueue_style( 'src-select2', get_template_directory_uri() . '/inc/admin/js/select2/dist/css/select2.min.css' );  
	wp_enqueue_script( 'src-select2', get_template_directory_uri() . '/inc/admin/js/select2/dist/js/select2.full.min.js', array('jquery'), false, false );
	
	wp_enqueue_script('chaos_jquery_ui', 'https://ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js', array('jquery'),false, false);
	wp_enqueue_script( 'repeater', get_template_directory_uri() . '/inc/admin/js/jquery.repeater.js', array('jquery'), false, false );

	wp_enqueue_script( 'admin-script',  get_template_directory_uri() . '/inc/admin/js/script.js', array('jquery'), false, false );
	wp_localize_script( 'admin-script', 'frontendajax', array( 'ajaxurl' => admin_url( 'admin-ajax.php' )));

	// wp_enqueue_script( 'bpopup', 'http://dinbror.dk/bpopup/assets/jquery.bpopup-0.9.4.min.js', array('jquery'), false, false );
	// wp_enqueue_script( 'easing', 'http://dinbror.dk/bpopup/assets/jquery.easing.1.3.js', array('jquery'), false, false );
}

function searchPlayer($search = ''){

	global $wpdb;
	$customer_name = $_POST['search_key'];

	$member_table = $wpdb->prefix. 'chaos_members';
	$query = "SELECT * FROM {$member_table} WHERE  name LIKE '".$customer_name."%' AND active = 1";
	$data['items'] =  $wpdb->get_results( $query ) ;
	echo json_encode($data);
	die();
}
add_action( 'wp_ajax_searchPlayer', 'searchPlayer' );
add_action( 'wp_ajax_nopriv_searchPlayer', 'searchPlayer' );
?>