<?php
	 global $wpdb;

 	// $pricing_table 			= $wpdb->prefix.'chaos_setting';
 	$pricing_detail_table 	= $wpdb->prefix.'chaos_football_pricing_details';
 	$billing_table       	= $wpdb->prefix.'chaos_football_billing';

	if(isset($_POST['action']) AND $_POST['action'] =='pricing') {
		$evening_price = (isset($_POST['price_evening']))? $_POST['price_evening']:2500;
		$morning_price = (isset($_POST['price_morning']))? $_POST['price_morning']:2000;
		$wpdb->update($pricing_detail_table ,array('price'=>$morning_price),array('inv_id'=>$_POST['inv_id'],'active'=>1,'session'=>'morning_session'));
		$wpdb->update($pricing_detail_table ,array('price'=>$evening_price),array('inv_id'=>$_POST['inv_id'],'active'=>1,'session'=>'evening_session'));
		$wpdb->update($billing_table ,array('ft_gst'=>$_POST['football_gst']),array('id'=>$_POST['inv_id'],'active'=>1));
		
		print('<script>window.location.href="admin.php?page=football_billing&pagess=2&inv_id='.$_POST['inv_id'].'"</script>');
		exit();
	}
$get_data = getPrice($_GET['inv_id']);
?>
<style>
.price_setting{
	width:100%;
}
.price_setting_in{
	width:50%;
	margin:0 auto;
	margin-top: 70px;
}
label
{
	font-size: 15px;
}

.submit_button{
	
    margin-top: 30px;
}
.label_top{
	float: left;
	width: 200px;	
}
.football_pricing_in{
	margin-top: 30px;
	margin-bottom: 10px;
}

.football_pricing_time{
	margin-top: 30px;
}
.div-table{
    border: 0px; 
}
</style>

</style>
<form class="form-horizontal" action="" method="POST" id="">
	<section class="price_setting">
		<div class="price_setting_in">
			<h3>Price Details</h3>
			<input type="hidden" name="inv_id" value="<?php echo $_GET['inv_id']; ?>">
			<div class="football_pricing">	
			<?php
			foreach ($get_data as $data) {
				if($data->session == 'morning_session'){
					echo '<div class="football_pricing_in">
					<div class="label_top"><label>Per Hour</label></div>
					<div><input type="text" name="price_morning" id="price_morning" onkeypress="return isNumberKeyWithDot(event)" value="'.$data->price.'" /></div>
					</div>';
				} else {
					echo '<div class="football_pricing_in">
					<div class="label_top"><label>Per Hour</label></div>
					<div><input type="text" name="price_evening" id="price_evening" onkeypress="return isNumberKeyWithDot(event)" value="'.$data->price.'" /></div>
				</div>';
					
				}
			}
			 ?>			
				
				
				<div class="football_pricing_in">
					<div class="label_top"><label>GST</label></div>
					<div><input type="text" name="football_gst" id="football_gst" onkeypress="return isNumberKeyWithDot(event)" value="<?php echo '18'; ?>" /> % </div>
				</div>
			
				<input type="hidden" name="action" id="submit" value="pricing"></br>	
				<input type="submit" id="submit" class="player_add submit_button" value="Submit">
		</div>
		
	</section>
</form>