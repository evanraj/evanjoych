

<STYLE TYPE="text/css">
.time_section,.morning_session,.evening_session{
	padding: 10px;
	/*margin-left: 20%;*/
}
.btn-success.active,.btn-success.active:focus,.btn-success:checked{
	background-color: #3a3eb1 !important;
}
.check-one {
	border-radius: 10px !important;
    width: 90px;
    height: 31px;
    margin-left: 2px !important;
    margin-top: 10px;
}
.btn-group-vertical>.btn, .btn-group>.btn{
	position: relative;
     float: none !important; 
}
</STYLE>
<div class="container-fluid">
	<div class="row">
		<section class="time_section">
			<form class="football_from" id="football_from">
				<div class="morning_session" data-toggle="buttons">
					<lable></lable>
					
					<label class="btn btn-success"> 
					 	<input type="checkbox"  name="action"  class="first-session"  value="morning" checked> 3 AM - 3 PM
					</label> 
					<b>PRICE - 2000 (PER HOUR)</b>
				</div>
				<div class="evening_session" data-toggle="buttons" >
			 		<lable></lable>
					<label class="btn btn-success" > 
					 	<input type="checkbox"  name="action"  class="second-session"  value="evening"> 3 PM - 3 AM
					</label> 	
					<b>PRICE - 2500 (PER HOUR)</b>
				</div>
				<div class=" morning-individual" data-toggle="buttons" style="margin-top: 10px;">
				 Morning Session
				 <div class="btn-group">	
				 	<?php
				 	 	$price_data  =footbal_pricing('morning_session', '60.00');
						foreach ($price_data as $p) { 
					?>
						<lable class="check-one btn btn-success">
							<input type="checkbox" autocomplete="off"  class="session" name="session[]" data-session = "<?php echo $p->session; ?>" value="<?php echo $p->id; ?>" /><?php echo $p->name; ?>	
							<input type="hidden" autocomplete="off"  class="price" name="session_time[<?php echo $p->id; ?>]" value="<?php echo $p->session; ?>" />
						</lable>
					<?php 
						}										 	 
					?>
				  </div>
		 		</div>
			 	<div class="evening-individual" data-toggle="buttons" style="display:none;margin-top: 10px;">
			 	Evening Session	
				 	<div class="btn-group">
					<?php
					 	 	$price_data  =footbal_pricing('evening_session', '60.00');

							foreach ($price_data as $p) { 
						?>
								<lable class="check-one btn btn-success">
									<input type="checkbox" autocomplete="off"  class="session" name="session[]" data-session = "<?php echo $p->session ?>" value="<?php echo $p->id; ?>" /><?php echo $p->name; ?>	
									<input type="hidden" autocomplete="off"  class="price" name="session_time[<?php echo $p->id; ?>]" value="<?php echo $p->session; ?>" />	
								</lable>
						<?php 
						
							}
											 	 
						?>
				 	</div>
			 	</div>
				<div class="individual_submit">
				 	<input type="button" class="btn btn-danger submit-time" style="margin-top: 10px;margin-left: 41%;" name="submit" value="submit"/>
				</div>
			</form>
			
		</section>
	</div>	
</div>

<script type="text/javascript">
jQuery(document).ready(function(){
	jQuery('.first-session').live('click change',function(){
	  if(jQuery('.first-session').is(':checked')){
	    jQuery('.morning-individual').css('display','block');
	  } else{
	  	 jQuery('.morning-individual').css('display','none');
	  }
	});
	jQuery('.second-session').live('click change',function(){
	  if(jQuery('.second-session').is(':checked')){
	   	  jQuery('.evening-individual').css('display','block');
	  } else{
	  	  jQuery('.evening-individual').css('display','none');
	  	  jQuery('.evening-individual').css('display','none');
	  }
	});

	jQuery('.submit-time').live('click change',function(){
		jQuery.ajax({
			method:"POST",
			dataType : 'json',
			url : frontendajax.ajaxurl,
			data : {
				action :'ft_invoice_create',
				data :jQuery('#football_from :input').serialize(),
			},
			success:function (data){
			   	if(data.redirect != 0) { 
                    setTimeout(function() {
                        managePopupContent(data);
                    }, 0);
                }
			}
		});	
	});

});
</script>
