<?php
if(isset($_POST['action']) && $_POST['action'] == 'tournament_filter') {
    $cpage = 1;
    parse_str($_POST['filter_data'], $params);
    $tournament_name = $params['tournament_name'];
    $ppage = $params['per_page'];
} else {
    $cpage = isset( $_GET['cpage'] ) ? abs( (int) $_GET['cpage'] ) : 1;
    $ppage = isset( $_GET['ppage'] ) ? abs( (int) $_GET['ppage'] ) : 20;
    $tournament_name = isset( $_GET['tournament_name'] ) ? $_GET['tournament_name'] : '';
}
$condition = '';
if($tournament_name != '') {
    $condition .= "AND tournament_name LIKE '${tournament_name}%' ";
}
$result_args = array(
    'orderby_field' => 'id',
    'page' => $cpage ,
    'order_by' => 'DESC',
    'items_per_page' => $ppage,
    'condition' => $condition,
);
$results = tournament_list_pagination($result_args);
?>

<table class="wp-list-table widefat fixed " cellspacing="0" >
    <thead>
        <tr style="background: rgb(229, 229, 229);color: #fff;">
            <th class="manage-column column-id"><span>S No</span></th>
            <th scope="col" id="wplc_name_colum" class="manage-column column-id"><span>Tournament Name</span></th>
            <th scope="col" id="wplc_name_colum" class="manage-column column-id"><span>Start</span></th>
            <th scope="col" id="wplc_name_colum" class="manage-column column-id"><span>End</span></th>
            <th scope="col" id="wplc_name_colum" class="manage-column column-id"><span>Action</span></th>
        </tr>
    </thead>
    <tbody id="the-list" class="list:wp_list_text_link">
 	<?php

    if(count($results['result'])>0) {  
        $start_count = $results['start_count'];
        foreach ($results['result'] as $t_value) {
        $start_count++;
	?>
  	<tr>
	  	<td class=""><?php echo $start_count; ?>
        </td>
	  	<td> <?php echo $t_value->tournament_name; ?></td>
	  	<td> <?php echo $t_value->tournament_start; ?></td>
        <td> <?php echo $t_value->tournament_end; ?></td>
	  	<td> <button>Delete</button>&nbsp; &nbsp;
        <a class="team-edit" href="<?php echo menu_page_url('add_tournament', 0).'&id='.$t_value->id; ?>">Edit</a></td>
  	</tr>
  	<?php
    }
}
 ?>
    </tbody>
</table>
<?php echo $results['pagination']; ?>