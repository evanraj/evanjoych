<?php
    if(isset($_POST['action']) && $_POST['action'] == 'tournament_filter') {
        parse_str($_POST['filter_data'], $params);
        $tournament_name = $params['tournament_name'];
        $ppage = $params['per_page'];
    } else {
        $ppage = isset( $_GET['ppage'] ) ? abs( (int) $_GET['ppage'] ) : 20;
        $tournament_name = isset( $_GET['tournament_name'] ) ? $_GET['tournament_name'] : '';
    }
?>
<div class="search_bar tournament_filter" style="margin-top:20px;">
    <label>Page :</label>
    <select name="per_page" id="per_page">
        <option value="5" <?php echo ($ppage == 5) ? 'selected' : ''; ?>>5</option>
        <option value="10" <?php echo ($ppage == 10) ? 'selected' : ''; ?>>10</option>
        <option value="15" <?php echo ($ppage == 15) ? 'selected' : ''; ?>>15</option>

        <option value="20" <?php echo ($ppage == 20) ? 'selected' : ''; ?>>20</option>
        <option value="50" <?php echo ($ppage == 50) ? 'selected' : ''; ?>>50</option>
        <option value="100" <?php echo ($ppage == 100) ? 'selected' : ''; ?>>100</option>
    </select>
    <input type="text" name="tournament_name" id="tournament_name" autocomplete="off" placeholder="Tournament Name" value="<?php echo $tournament_name; ?>">
</div>

<div class="listing-template">
    <?php include( get_template_directory().'/inc/admin/tournament/ajax/list-tournament.php' ); ?>
</div>

<script type="text/javascript">
    jQuery(document).ready(function () {
        jQuery('.search_bar input').on('change', function(){
            jQuery.ajax({
                type: "POST",
                url: frontendajax.ajaxurl,
                data: {
                  action : 'tournament_filter',
                  filter_data : jQuery('.tournament_filter :input').serialize(),
                },
                success: function (data) {
                  jQuery('.listing-template').html(data);
                }
            });
        });
    });
</script>