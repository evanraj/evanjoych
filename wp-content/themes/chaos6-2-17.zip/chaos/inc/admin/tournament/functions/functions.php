<?php

require get_template_directory() . '/inc/admin/tournament/pagination-function.php';


function chaos_tournament_scripts() {
	wp_enqueue_script('tournament_script', get_template_directory_uri().'/inc/admin/tournament/js/tournament.js', array('jquery'),false, false);
}
add_action( 'admin_enqueue_scripts', 'chaos_tournament_scripts' );


function updateTeamPoints( $match_status = 0, $match_id = 0, $data = array() ) {
	global $wpdb;
	$chaos_tournament_points = $wpdb->prefix.'chaos_tournament_points';

	$wpdb->update($chaos_tournament_points, array('active' => 0), array('match_id' => $match_id, 'team_id' => $data['team_id'], 'active' => 1) );
	if($match_status == 2) {
		$wpdb->insert($chaos_tournament_points, $data);
	}

}



function tournament_filter() {
	include( get_template_directory().'/inc/admin/tournament/ajax/list-tournament.php' );
	die();
}
add_action( 'wp_ajax_tournament_filter', 'tournament_filter' );
add_action( 'wp_ajax_nopriv_tournament_filter', 'tournament_filter' );

?>