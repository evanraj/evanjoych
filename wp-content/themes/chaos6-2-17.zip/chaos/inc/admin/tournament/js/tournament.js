jQuery(document).ready(function () {
	jQuery('.team1_goal, .team1_own_goal, .team2_goal, .team2_own_goal').on('change',function(){
		calculateGoal();
	})
});



function calculateGoal() {
	var team1_goal = 0;
	var team2_own_goal = 0;

	var team2_goal = 0;
	var team1_own_goal = 0;

	var team1_total = 0;
	var team2_total = 0;
	var winner = '-';
	var looser = '-';


	jQuery('.team1_goal').each(function(){
		team1_goal += parseInt(jQuery(this).val());
	});

	jQuery('.team2_own_goal').each(function(){
		team2_own_goal += parseInt(jQuery(this).val());
	});


	jQuery('.team2_goal').each(function(){
		team2_goal += parseInt(jQuery(this).val());
	});

	jQuery('.team1_own_goal').each(function(){
		team1_own_goal += parseInt(jQuery(this).val());
	});

	team1_total = team1_goal + team2_own_goal;
	team2_total = team2_goal + team1_own_goal;

	jQuery('.team1_total').val(team1_total);
	jQuery('.team2_total').val(team2_total);


	if( team1_total > team2_total ) {
		winner = jQuery('.team1_id').val();
		looser = jQuery('.team2_id').val();
	}

	if( team1_total < team2_total ) {
		winner = jQuery('.team2_id').val();
		looser = jQuery('.team1_id').val();
	}


	jQuery('.winner_id').val(winner);
	jQuery('.looser_id').val(looser);

}