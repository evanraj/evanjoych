<style type="text/css">
	.match_title {
		text-align: center;
	}
	.span_team {
		font-size: 24px;
		background: #fff;
	    padding: 20px;
	    border-radius: 30px;
	}
	.style_vs {
		font-size: 20px;
		color: red;
	}
	.team1_container, .team2_container {
		width: 50%;
		float: left;
		background: #fff;
	}
	.detail_container {
		margin-top: 50px;
		background: #fff;
	}
	.team1_in, .team2_in {
		padding: 30px;
	}
</style>




<?php 

	global $wpdb;
	$shedule_table = $wpdb->prefix.'chaos_tournament_schedule';
	$player_goal_table = $wpdb->prefix.'chaos_tournament_player_goal';
	$chaos_tournament_points = $wpdb->prefix.'chaos_tournament_points';

	$match_id = ( isset($_GET['match_id']) && $_GET['match_id'] != '' ) ? $_GET['match_id'] : 0;


	if(isset($_POST['action']) && $_POST['action'] == 'update_score') {

		$match_id = $_POST['match_id'];

		if($_POST['team1_id'] == $_POST['winner_id']) {
			$team1_point = array('team_id' => $_POST['team1_id'], 'points' => 2);
			$team2_point = array('team_id' => $_POST['team2_id'], 'points' => 0);
		} else if($_POST['team2_id'] == $_POST['winner_id']) {
			$team1_point = array('team_id' => $_POST['team1_id'], 'points' => 0);
			$team2_point = array('team_id' => $_POST['team2_id'], 'points' => 2);
		} else {
			$team1_point = array('team_id' => $_POST['team1_id'], 'points' => 1);
			$team2_point = array('team_id' => $_POST['team2_id'], 'points' => 1);
		}
		$team1_point['match_id'] = $match_id;
		$team2_point['match_id'] = $match_id;

		updateTeamPoints($_POST['match_status'], $match_id, $team1_point);
		updateTeamPoints($_POST['match_status'], $match_id, $team2_point);


		//Update Match Detail
		$data = array('played' => $_POST['match_status'], 'score_team1' => $_POST['team1_goal'], 'score_team2' => $_POST['team2_goal'], 'winner' => $_POST['winner_id'], 'loser' => $_POST['looser_id']);
		$wpdb->update($shedule_table, $data, array('id' => $_POST['match_id']));

		//Reset Individual Goals
		$wpdb->update($player_goal_table, array('active' => 0), array('match_id' => $match_id ));

		//Update team1 player Individual Goals
		foreach ($_POST['team1'] as $t1_value) {
			$player_id = $t1_value['id'];
			$goal = $t1_value['goal'];
			$own_goal = $t1_value['own_goal'];
			$team_id = $_POST['team1_id'];
			
			$wpdb->insert( $player_goal_table, array('match_id' => $match_id, 'team_id' => $team_id, 'player_id' => $player_id, 'goals' => $goal, 'own_goals' => $own_goal) );
		}

		//Update team2 player Individual Goals
		foreach ($_POST['team2'] as $t2_value) {
			$player_id = $t2_value['id'];
			$goal = $t2_value['goal'];
			$own_goal = $t2_value['own_goal'];
			$team_id = $_POST['team2_id'];

			$wpdb->insert( $player_goal_table, array('match_id' => $match_id, 'team_id' => $team_id, 'player_id' => $player_id, 'goals' => $goal, 'own_goals' => $own_goal) );
		}





	}




	$match_detail = getMatchDetails($match_id);

	$team1_players = get_match_detail_by_team($match_detail->team1, $match_id);
	$team2_players = get_match_detail_by_team($match_detail->team2, $match_id);

?>
<style type="text/css">
	.table-head {
		background-color: #060606;
		color: #fff;
	}
	table {
	    border-collapse: collapse;
	    width: 100%;
	}
	tr{
		border: 4px solid #959696;
	}
	th, td {
	    text-align: left;
	    padding: 8px;
	    border: 3px solid #959696;
	}
	table input[type=number] {
		width: 50px;
	}

	tr:nth-child(even){background-color: #cecece;}
	.update_match_score {
		background-color: #fff;
		text-align: center;
		padding: 50px;
	}
	.update_match_score input {
		padding: 20px;
	}
	.text-label {
		float: left;
		width: 200px;
		font-size: 22px;
	}
	.value-label {
		font-size: 22px;
	}
	.value-label {
		float: left;
	}
	.goal-total {
		margin-top: 20px;
		margin-bottom: 20px;
	}
	.match_status {
		text-align: center;
		padding-top: 20px;
	}
</style>
<h1>Match Details</h1>
<form action="" method="GET">
	<input type="text" name="match_id">
	<input type="submit" value="Search">
	<input type="hidden" name="page" value="update_match">
</form>

<div class="match_title">
	<span class="span_team"><?php echo $match_detail->team1_name; ?></span>
	<span class="style_vs">VS</span>
	<span class="span_team"><?php echo $match_detail->team2_name; ?></span>
</div>

<form action="" method="POST">
	

	<div class="detail_container">
		<div class="match_status">
			<span style="font-size:20px;">Match Status : </span>

			<input type="radio" name="match_status" value="0" <?php echo ($match_detail->played == 0) ? 'checked' : ''; ?>> Pending
			<input type="radio" name="match_status" value="1" <?php echo ($match_detail->played == 1) ? 'checked' : ''; ?>> Live
			<input type="radio" name="match_status" value="2" <?php echo ($match_detail->played == 2) ? 'checked' : ''; ?>> Finished
			<input type="hidden" name="match_id" value="<?php echo $match_id; ?>">

			<input type="hidden" name="winner_id" class="winner_id" value="-">
			<input type="hidden" name="looser_id" class="looser_id" value="-">
		</div>


		<div class="board-update-container">
			<div class="team1_container">
				<div class="team1_in">
					<div class="team_title">
						<div class="text-label">
							Team Name
						</div>
						<div class="value-label">
							: <?php echo ucfirst( $match_detail->team1_name ); ?>
						</div>
					</div>
					<div style="clear:both;"></div>
					<div class="goal-total">
						<div class="text-label">
							Total Goal
						</div>
						<div class="value-label">
							: <?php echo '<input type="number" name="team1_goal" class="team1_total" value="'.$match_detail->score_team1.'" min="0">';?>
							<input type="hidden" name="team1_id" class="team1_id" value="<?php echo $team1_players['team_data']->id; ?>">
						</div>
						<div style="clear:both;"></div>
					</div>

					<div class="">

						<table>
						  <tr class="table-head">
						    <th>Player</th>
						    <th>Goals</th>
						    <th>Own Goals</th>
						  </tr>
							<?php
								if($team1_players['members_data']) {
									$i = 0;
									foreach ($team1_players['members_data'] as $p1_value) {
							?>
								<tr>
									<td>
									<?php echo $p1_value->name; ?>
									<input type="hidden" name="team1[<?php echo $p1_value->id; ?>][id]" value="<?php echo $p1_value->id; ?>">
									</td>
									<td><input type="number" name="team1[<?php echo $p1_value->id; ?>][goal]" value="<?php echo $p1_value->goals ?>" min="0" class="team1_goal"></td>
									<td><input type="number" name="team1[<?php echo $p1_value->id; ?>][own_goal]" value="<?php echo $p1_value->own_goals; ?>" min="0" class="team1_own_goal"></td>
								</tr>
							<?php
										$i++;
									}
								}
							?>

						</table>


					</div>
				</div>
			</div>
			<div class="team2_container">
				<div class="team2_in">



					<div class="team_title">
						<div class="text-label">
							Team Name
						</div>
						<div class="value-label">
							: <?php echo ucfirst( $match_detail->team2_name ); ?>
						</div>
					</div>
					<div style="clear:both;"></div>
					<div class="goal-total">
						<div class="text-label">
							Total Goal
						</div>
						<div class="value-label">
							: <?php echo '<input type="number" name="team2_goal" class="team2_total" value="'.$match_detail->score_team2.'" min="0">';?>
							<input type="hidden" name="team2_id" class="team2_id" value="<?php echo $team2_players['team_data']->id; ?>">
						</div>
						<div style="clear:both;"></div>
					</div>



				
					<div class="">
						<table>
						  <tr class="table-head">
						    <th>Player</th>
						    <th>Goals</th>
						    <th>Own Goals</th>
						  </tr>
							<?php
								if($team2_players['members_data']) {
									foreach ($team2_players['members_data'] as $p2_value) {
							?>
								<tr>
									<td>
									<?php echo $p2_value->name; ?>
									<input type="hidden" name="team2[<?php echo $p2_value->id; ?>][id]" value="<?php echo $p2_value->id; ?>">
									</td>
									<td><input type="number" name="team2[<?php echo $p2_value->id; ?>][goal]" value="<?php echo $p2_value->goals ?>" min="0" class="team2_goal"></td>
									<td><input type="number" name="team2[<?php echo $p2_value->id; ?>][own_goal]" value="<?php echo $p2_value->own_goals ?>" min="0" class="team2_own_goal"></td>
								</tr>
							<?php
									}
								}
							?>

						</table>
					</div>
				</div>
			</div>
			<div style="clear:both;"></div>
		</div>



		<div class="update_match_score">
			<?php
				echo '<input type="hidden" name="action" value="update_score">';
			?>
			<input type="submit" name="update_score" value="Update Match Detail">
		</div>
	</div>


</form>	