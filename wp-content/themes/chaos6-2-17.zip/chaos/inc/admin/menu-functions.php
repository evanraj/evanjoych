<?php 
add_action('admin_menu', 'admin_menu_register');

function admin_menu_register(){

    add_menu_page(
        __( 'Add Team', 'chaos'),
        'Add Team',
        'manage_options',
        'add_team',
        'add_team',
        'dashicons-universal-access',
        2
    );
    add_submenu_page('add_team', 'List Team', 'List Team', 'manage_options', 'list_team', 'list_team');


    add_menu_page(
        __( 'Tournament', 'chaos'),
        'Chaso Tournament',
        'manage_options',
        'add_tournament',
        'add_tournament',
        'dashicons-awards',
        2
    );
    add_submenu_page('add_tournament', 'Add Tournament', 'Add Tournament', 'manage_options', 'add_tournament', 'add_tournament');
    add_submenu_page('add_tournament', 'List Tournament', 'List Tournament', 'manage_options', 'list_tournament', 'list_tournament' );
    add_submenu_page('add_tournament', 'Update Match Detail', 'Update Match Detail', 'manage_options', 'update_match', 'update_match' );
}


















function add_team() {
    require 'team/views/add-team.php';
}

function list_team() {
    require 'team/list-template/list-team.php';
}


function add_tournament() {
    require 'tournament/views/add-tournament.php';
}
function list_tournament() {
    require 'tournament/list-template/list-tournament.php';
}
function update_match() {
    require 'tournament/views/update_match.php';
}




function remove_admin_menu() {
    remove_filter( 'update_footer', 'core_update_footer' ); 
    remove_menu_page( 'index.php' );                  //Dashboard
    remove_menu_page( 'jetpack' );                    //Jetpack* 
    remove_menu_page( 'edit.php' );                   //Posts
    remove_menu_page( 'upload.php' );                 //Media
    remove_menu_page( 'edit.php?post_type=page' );    //Pages
    remove_menu_page( 'edit.php?post_type=shop_order' );    //Pages
    remove_submenu_page('woocommerce', 'woocommerce_settings');
    remove_menu_page( 'edit.php?post_type=wpseo_dashboard' );    //Pages
    remove_menu_page( 'edit-comments.php' );          //Comments
    remove_menu_page( 'themes.php' );                 //Appearance
    remove_menu_page( 'plugins.php' );                //Plugins
    remove_menu_page( 'users.php' );                  //Users
    remove_menu_page( 'tools.php' );                  //Tools
    remove_menu_page( 'options-general.php' );        //Settings
}
add_action( 'admin_menu', 'remove_admin_menu' );





?>