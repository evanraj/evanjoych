<?php
global $wpdb;

if(isset($_POST['action']) AND $_POST['action'] =='birthday') {
	
	$data = lazer_invoice_create();
	 	$billing_table       	= $wpdb->prefix.'chaos_lazertag_billing';
	 	$price_data = array(
	 		'area1'	 			=> $_POST['area1'],
	 		'area2'		 		=> $_POST['area2'],
	 		'area3'				=> $_POST['area3'],
	 		'from_time'			=> $_POST['from'],
	 		'to_time'			=> $_POST['to'],
	 		'from_date'			=> $_POST['from_date'],
	 		'lazertag_type'		=> $_POST['lazertag_type'],
	 		'lazertag_amount'  	=> $_POST['lazertag_hours'],
	 		'lazertag_gst'  	=> $_POST['lazertag_gst'],
	 		);
	 	$wpdb->update($billing_table ,$price_data,array('id'=>$data['id'],'active'=>1));
		print('<script>window.location.href="admin.php?page=lazertag_billing&pagess=2&inv_id='.$data['id'].'&action=member_setting"</script>');
		exit();
	}
	

	if($_GET['lazertag_type'] == 'birthday'){
		$price = 5000;
		$display = "style='display:block'";
	} else if ($_GET['lazertag_type'] == 'corporate'){
		$price = 5000;
		$display = "style='display:block'";
	} else {
		$price = 250;
		$display = "style='display:none'";
	}


?>
<style>
.price_setting{
	width:100%;
}
.price_setting_in{
	/*width:50%;*/
	margin:0 auto;
	margin-top: 70px;
}
label
{
	font-size: 15px;
}

.submit_button{
	
    margin-top: 30px;
}
.label_top{
	float: left;
	width: 200px;	
	height: 43px;
}
.football_pricing_in{
	margin-top: 30px;
	margin-bottom: 10px;
}

.football_pricing_time{
	margin-top: 30px;
}
.div-table{
    border: 0px; 
}
input[type=checkbox], input[type=radio] {
	margin: 4px 4px 0 !important;
}
</style>

</style>
<form class="form-horizontal" action="" method="POST" id="">
	<section class="price_setting">
		<div class="price_setting_in">
			<h3>Price Details</h3>
			<!-- <input type="hidden" name="timing" value="<?php echo $_GET['timing']; ?>">
			<input type="hidden" name="from" value="<?php echo $_GET['from']; ?>">
			<input type="hidden" name="to" value="<?php echo $_GET['to']; ?>">
			<input type="hidden" name="from_date" value="<?php echo $_GET['from_date']; ?>">
			<input type="hidden" name="to_date" value="<?php echo $_GET['to_date']; ?>"> -->
			<div class="football_pricing">				
				<div class="football_pricing_in">
					<div class="label_top"><label>Playing Hours</label></div>
					<div>
						<div>
							<p id="basicExample">
							    From : 
							    	<input type="text" name="from_date" class="date start" />
							    	<input type="text" name="from" class="time start" /> 
							    To:
							    	<input type="text" name="to" class="time end" />
							    	<!-- <input type="text" name="to" class="date end" /> -->
							</p>
						</div>
					</div>
				</div>
				<div class="football_pricing_in">
					<div class="label_top"><label>Per Game/Per Head</label></div>
					<div><input type="text" name="lazertag_hours" id="lazertag_hours" class="lazertag_hours" value="<?php echo $price; ?>" /></div>
				</div>
				<div class="football_pricing_in">
					<div class="label_top"><label>GST</label></div>
					<div>
						<input type="hidden" name="lazertag_type" value="<?php echo $_GET['lazertag_type']; ?>" class="lazertag_type"/>
						<input type="text" name="lazertag_gst" id="lazertag_gst" value="<?php echo '18'; ?>" /> % 
					</div>
				</div>
				<div class="football_pricing_in " <?php echo $display; ?>>
					<div class="label_top"><label>Playing area</label></div>
					<div>
						<input type="checkbox" name="area1" class="area1" value="console">Console Gaming(PS4)<br>
  						<input type="checkbox" name="area2" class="area2" value="vr">VR Gaming - 1000/Per Hour<br>
  						<input type="checkbox" name="area3" class="area3" value="motion">Retro & Motion Sensor Game - 400/Per Hour<br>
					</div>
				</div>
			</div>		

			
				<input type="hidden" name="action" id="submit" value="birthday"></br>	
				<input type="submit" id="submit" class="player_add birthday_submit" value="Submit">
		</div>
		
	</section>
</form>
<script type="text/javascript">
jQuery(document).ready(function(){ 

	jQuery('.area2').on('click',function(){
		var price =isNaN(parseFloat(jQuery('.lazertag_hours').val())) ? 0 :parseFloat(jQuery('.lazertag_hours').val());
		if(jQuery('.area2').is(':checked')){
			jQuery('.lazertag_hours').val(price+1000);
		}
		else{
			jQuery('.lazertag_hours').val(price-1000);
		}
	});
	jQuery('.area3').on('click',function(){	

		var price =isNaN(parseFloat(jQuery('.lazertag_hours').val())) ? 0 :parseFloat(jQuery('.lazertag_hours').val());
		if(jQuery('.area3').is(':checked')){
			jQuery('.lazertag_hours').val(price+400);
		}
		else{
			jQuery('.lazertag_hours').val(price-400);
		}
	});
	jQuery('#basicExample .time').timepicker({
        'showDuration': true,
        'timeFormat': 'g:ia'
    });

    jQuery('#basicExample .date').datepicker({
        'dateFormat': 'mm/dd/yy',
        'autoclose': true
    });


    jQuery('#basicExample .time1').timepicker({
        'showDuration': true,
        'timeFormat': 'g:ia'
    });

    jQuery('#basicExample .date1').datepicker({
        'dateFormat': 'mm/dd/yy',
        'autoclose': true
    });

	jQuery('#basicExample').datepair({
	    parseDate: function(input){
	        var picker = jQuery(input).data('pikaday');
	        return picker.getDate();
	    },
	    updateDate: function(input, dateObj){
	        var picker = jQuery(input).data('pikaday');
	        return picker.setDate(dateObj);
	    }
	});
    //initialize datepair
    var basicExampleEl = document.getElementById('basicExample');
    var datepair = new Datepair(basicExampleEl);


	
});
</script>