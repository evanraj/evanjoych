<STYLE TYPE="text/css">
.time_section,.morning_session,.evening_session{
	padding: 10px;
}
</STYLE>
<div class="container-fluid">
	<div class="row">
		<section class="time_section">
			<div>
				<div class="morning_session1">
					<div class="morning_session" data-toggle="buttons">
						<lable>Morning Session</lable>
						<label class="btn btn-success"> 
						 	<input type="checkbox" autocomplete="off" name="action"  class="first-session"  value="morning"> 3 AM - 3 PM
						</label> 
						
					</div>
					<div class="morning_timing" style="display: none;">
						<input type="button" name="timing"  class="btn btn-danger one_or_more one"  value="One Hour">
						<input type="button" name="timing"  class="btn btn-danger one_or_more more"  value="More Than One Hour"> 
					</div>
					<div class="morning-more-than-one" style="display: none;margin-top: 10px;">
						From : <input type="time" name="time_value_from" class="time_value_from">
						To : <input type="time" name="time_value_to" class="time_value_to">
						<input type="buttons" data-session="morning_session" class="btn btn-info time_value" name="time_value" value="Submit">
					</div>
					<div class="btn-group morning-one-hour" data-toggle="buttons" style="display:none;margin-top: 10px;">
						 <label class="btn btn-danger"> 
						 	<input type="checkbox" autocomplete="off"  class="session" data-session = "morning_session" value="3am-4am"> 3 AM - 4 AM
						 </label> 
						 <label class="btn btn-warning"> 
						 	<input type="checkbox" autocomplete="off"  class="session" data-session = "morning_session" value="4am-5am"> 4 AM - 5 AM
						 </label> 
						 <label class="btn btn-success"> 
						 	<input type="checkbox" autocomplete="off"  class="session" data-session = "morning_session" value="5am-6am"> 5 AM - 6 AM
						 </label>
						  <label class="btn btn-danger"> 
						  	<input type="checkbox" autocomplete="off"  class="session" data-session = "morning_session" value="6am-7am"> 6 AM - 7 AM
						 </label>
						 <label class="btn btn-info"> 
						 	<input type="checkbox"  autocomplete="off"  class="session" data-session = "morning_session" value="7am-8am"> 7 AM - 8 AM
						 </label>
						  <label class="btn btn-success"> 
						  	<input type="checkbox" autocomplete="off"  class="session" data-session = "morning_session" value="8am-9am"> 8 AM - 9 AM
						 </label>
						 <label class="btn btn-primary"> 
						 	<input type="checkbox" autocomplete="off"  class="session" data-session = "morning_session" value="9am-10am"> 9 AM - 10AM 
						 </label>
						  <label class="btn btn-danger"> 
						  	<input type="checkbox" autocomplete="off"  class="session" data-session = "morning_session" value="10am-11am"> 10 AM - 11 AM
						 </label> 
						 <label class="btn btn-primary"> 
						 	<input type="checkbox" autocomplete="off"  class="session" data-session = "morning_session" value="11am-12am"> 11 AM - 12 AM
						 </label> 
						 <label class="btn btn-success"> 
						 	<input type="checkbox" autocomplete="off"  class="session" data-session = "morning_session" value="12pm-1pm"> 12 PM -1 PM
						 </label>
						  <label class="btn btn-danger"> 
						  	<input type="checkbox" autocomplete="off"  class="session" data-session = "morning_session" value="1pm-2pm"> 1 PM - 2 PM
						 </label>
						  <label class="btn btn-info"> 
						  	<input type="checkbox" autocomplete="off"  class="session" data-session = "morning_session" value="2pm-3pm"> 2 PM - 3 PM
						 </label> 
			 		</div>
				</div>
				
			 	<div class="evening_session1">
				 	<div class="evening_session" data-toggle="buttons" >
				 		<lable>Evening Session</lable>
						<label class="btn btn-success" > 
						 	<input type="checkbox" autocomplete="off" name="action"  class="first-session"  value="evening"> 3 AM - 3 PM
						</label> 	
					</div>
					<div class="evening_timing" style="display: none;">
						<input type="button" name="timing"  class="btn btn-danger one_or_more"  value="One Hour">
						<input type="button" name="timing"  class="btn btn-danger one_or_more"  value="More Than One Hour"> 
					</div>
				 	<div class="btn-group evening-buttons" data-toggle="buttons" style="display:none;">
				 		<label class="btn btn-success "> 
				 			<input type="checkbox" autocomplete="off"  class="session" data-session = "evening_session" value="3am-4pm"> 3 PM - 4 PM
						 </label>
						 <label class="btn btn-warning"> 
						 	<input type="checkbox" autocomplete="off"  class="session" data-session = "evening_session" value="4pm-5pm"> 4 PM - 5 PM
						 </label>
						 <label class="btn btn-success"> 
						 	<input type="checkbox" autocomplete="off"  class="session" data-session = "evening_session" value="5pm-6pm"> 5 PM - 6 PM
						 </label>
						  <label class="btn btn-info"> 
						  	<input type="checkbox" autocomplete="off"  class="session" data-session = "evening_session" value="6pm-7pm"> 6 PM - 7 PM
						 </label>
						  <label class="btn btn-success"> 
						  	<input type="checkbox" autocomplete="off"  class="session" data-session = "evening_session" value="7pm-8pm"> 7 PM - 8PM
						 </label>
						  <label class="btn btn-primary"> 
						  	<input type="checkbox" autocomplete="off"  class="session" data-session = "evening_session" value="8pm-9pm"> 8 PM -9 PM
						 </label>
						  <label class="btn btn-danger"> 
						  	<input type="checkbox" autocomplete="off"  class="session" data-session = "evening_session" value="9pm-10pm"> 9 PM - 10 PM
						 </label>
						  <label class="btn btn-success"> 
						  	<input type="checkbox" autocomplete="off"  class="session" data-session = "evening_session" value="10pm-11pm"> 10 PM - 11 PM
						 </label> 
						 <label class="btn btn-danger"> 
						 	<input type="checkbox" autocomplete="off"  class="session" data-session = "evening_session" value="11pm-12pm"> 11 PM -12 PM
						 </label>
						  <label class="btn btn-info"> 
						  	<input type="checkbox" autocomplete="off"  class="session" data-session = "evening_session" value="12pm-1am"> 12 PM - 1 AM
						 </label> 
						 <label class="btn btn-success"> 
						 	<input type="checkbox" autocomplete="off"  class="session" data-session = "evening_session" value="1am-2am"> 1 AM - 2 AM
						 </label>
						 <label class="btn btn-warning"> 
						 	<input type="checkbox" autocomplete="off"  class="session" data-session = "evening_session" value="2am-3am"> 2 AM - 3 AM
						</lable>
				 	</div>
				 <div>

			</div>
		</section>
	</div>	
</div>

<script type="text/javascript">
jQuery(document).ready(function(){

	jQuery('.first-session').live('click change',function(){

	  var session_val = jQuery('.first-session:checked').val();
	  if(session_val == "morning"){
	    jQuery('.evening_session').css('display','none');
	    jQuery('.morning_timing').css('display','block');
	    jQuery('.evening_timing').css('display','none');
	  } else if(session_val == "evening"){
	    jQuery('.morning_session').css('display','none');
	    jQuery('.morning_timing').css('display','none');
	    jQuery('.evening_timing').css('display','block');
	  } else{
	  	console.log("ok");
	  }

	});

	jQuery('.one_or_more').click(function(){
		var player = jQuery(this).val();
		if(player == "One Hour"){
			jQuery('.more').css('display','none');
			jQuery('.morning-one-hour').css('display','block');
		} else if( player == "More Than One Hour" ){
			jQuery('.one').css('display','none');
			jQuery('.morning-more-than-one').css('display','block');
		} else{
			console.log("ok");
		}
	});
	jQuery('.session').live('click change',function(){
		var buttons_val = jQuery('.session:checked').val();
		var session_timing = jQuery(this).data('session');

		jQuery.ajax({
			method:"POST",
			dataType : 'json',
			url : frontendajax.ajaxurl,
			data : {
				action :'move_to_price',
				value  : buttons_val,
				session : session_timing,
				from : '',
				to : '',
			},
			success:function (data){
				   if(data.redirect != 0) { 
                        setTimeout(function() {
                            managePopupContent(data);
                        }, 1000);
                    }

			}


			});
		
	});

	jQuery('.time_value').on('click',function(){
		var time_value_from = jQuery('.time_value_from').val();
		var time_value_to   = jQuery('.time_value_to').val();
		var session_timing  = jQuery(this).data('session');
		jQuery.ajax({
			method:"POST",
			dataType : 'json',
			url : frontendajax.ajaxurl,
			data : {
				action 	:'move_to_price',
				value  	: '',
				session : session_timing,
				from 	: time_value_from,
				to 		: time_value_to,
			},
			success:function (data){
				console.log("sdsds");

			}


			});
		
	});
});
</script>