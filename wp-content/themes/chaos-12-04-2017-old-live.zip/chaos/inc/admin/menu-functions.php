<?php 
add_action('admin_menu', 'admin_menu_register');

function admin_menu_register(){

    add_menu_page(
        __( 'Add Team', 'chaos'),
        'Add Team',
        'manage_options',
        'add_team',
        'add_team',
        'dashicons-universal-access',
        2
    );
    add_submenu_page('add_team', 'List Team', 'List Team', 'manage_options', 'list_team', 'list_team');


    add_menu_page(
        __( 'Tournament', 'chaos'),
        'Chaso Tournament',
        'manage_options',
        'add_tournament',
        'add_tournament',
        'dashicons-awards',
        2
    );
    add_submenu_page('add_tournament', 'Add Tournament', 'Add Tournament', 'manage_options', 'add_tournament', 'add_tournament');
    add_submenu_page('add_tournament', 'List Tournament', 'List Tournament', 'manage_options', 'list_tournament', 'list_tournament' );
    add_submenu_page('add_tournament', 'Update Match Detail', 'Update Match Detail', 'manage_options', 'update_match', 'update_match' );




/*Sowmiya*/


//Utility Manager

    add_menu_page(
        __( 'Utility', 'chaos'),
        'Add Utility',
        'manage_options',
        'add_utility',
        'add_utility',
        'dashicons-email-alt',
        2
    );
    add_submenu_page('add_utility', 'Add Utility', 'Add Utility', 'manage_options', 'add_utility', 'add_utility');
    add_submenu_page('add_utility', 'View Utility', 'View Utility', 'manage_options', 'view_utility', 'view_utility' );


    //Billing Manager
    add_menu_page(
        __( 'Billing', 'chaos'),
        'Add Billing',
        'manage_options',
        'add_billing',
        'add_billing',
        'dashicons-email-alt',
        3
    );
    //Foot ball Billing
    add_submenu_page('add_billing', 'Foot Ball Billing', 'Foot Ball Billing', 'manage_options', 'football_billing', 'football_billing');
    add_submenu_page('add_billing', 'View Foot Ball Billing', 'View Foot Ball Billing', 'manage_options', 'view_football_billing', 'view_football_billing' );
    //lazer billing
    add_submenu_page('add_billing', 'Lazer tag Billing', 'Lazer tag Billing', 'manage_options', 'lazertag_bill', 'lazertag_bill');
    add_submenu_page('add_billing', 'View Lazer tag Billing', 'View Lazer tag Billing', 'manage_options', 'view_lazertag_bill', 'view_lazertag_bill' );
    //computer gaming
    add_submenu_page('add_billing', 'Gaming Billing', 'Gaming Billing', 'manage_options', 'gaming_billing', 'gaming_billing');
    add_submenu_page('add_billing', 'Computer Gaming Billing', 'View Gaming Billing', 'manage_options', 'view_gaming_billing', 'view_gaming_billing' );

    //Price_Setting
    add_submenu_page('add_billing', 'Price Setting', 'Price Setting', 'manage_options', 'add_price_setting', 'add_price_setting' );

    //Display Football Billing
    add_submenu_page('add_billing', 'Display Football Billing', '', 'manage_options', 'display_football', 'display_football' );
    //Display Gaming Billing
    add_submenu_page('add_billing', 'Display Gaming Billing', '', 'manage_options', 'display_gaming', 'display_gaming' );
    //Display Lazer Tag Billing
    add_submenu_page('add_billing', 'Display Lazer Tag', '', 'manage_options', 'display_lazertag', 'display_lazertag' );






    /*Evan*/

    add_menu_page(
            __( 'Chaos Members ', 'chaos'),
            'Chaso Members',
            'manage_options',
            'add_chaos_member',
            'add_chaos_member',
            'dashicons-universal-access-alt',
            2
        );
        add_submenu_page('add_chaos_member', 'Add Member', 'Add Member', 'manage_options', 'add_chaos_member', 'add_chaos_member');
        add_submenu_page('add_chaos_member', 'List Member', 'List Member', 'manage_options', 'list_chaos_member', 'list_chaos_member' );

    add_menu_page(
            __( 'Credit Points', 'chaos'),
            'Credit Points',
            'manage_options',
            'list_credits',
            'list_credits',
            'dashicons-star-half',
            2
        );




}


















function add_team() {
    require 'team/views/add-team.php';
}

function list_team() {
    require 'team/list-template/list-team.php';
}


function add_tournament() {
    require 'tournament/views/add-tournament.php';
}
function list_tournament() {
    require 'tournament/list-template/list-tournament.php';
}
function update_match() {
    require 'tournament/views/update_match.php';
}



/*Sowmiya*/


//Utility
function add_utility() {
    require 'utility-manager/views/add-utility.php';
}

function view_utility() {
    require 'utility-manager/list-template/list_utility.php';
}


//Billing
//Foot ball Billing
function football_billing() {
    require 'billing/views/football_billing.php';
}

function view_football_billing() {
    require 'billing/list-template/list_football_billing.php';
}
//<---- End Foot ball Billing ----->


//Lazer Tag Billing
function lazertag_bill() {
    require 'billing/views/lazertag_billing.php';
}

function view_lazertag_bill() {
    require 'billing/list-template/list_lazertag_billing.php';
}
//<--- End Lazer Tag Billing--->


//Gaming Billing
function gaming_billing() {
    require 'billing/views/gaming_billing.php';
}

function view_gaming_billing() {
    require 'billing/list-template/list_gaming_billing.php';
}
//<--- End Gaming Billing--->

function add_price_setting() {
     require 'billing/views/price_setting.php';
}

//Display Football Billing
function display_football(){
     require 'billing/views/display_football_billing.php';
}

//Display Gaming Billing
function display_gaming(){
     require 'billing/views/display_gaming_billing.php';
}


//Display Lazer Tag
function display_lazertag(){
     require 'billing/views/display_lazertag_billing.php';
}





/*Evan*/
function add_chaos_member() {
    require 'chaos_members/views/add-chaos-member.php';
}

function list_chaos_member() {
    require 'chaos_members/members.php';
}

function list_credits() {
    require 'credits/credits.php';
}
?>