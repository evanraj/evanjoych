<?php

date_default_timezone_set('Asia/Kolkata');
$date = date('Y-m-d');
global $wpdb;
$gaming_billing 			= $wpdb->prefix. 'chaos_gaming_billing';
$gaming_billing_relation 	= $wpdb->prefix. 'chaos_gaming_billing_relation';
if(isset($_POST['action']) AND $_POST['action'] == 'gaming_billing_submit'  ) {


	if(isset($_POST['gaming_member_no']) AND $_POST['gaming_member_no'] == ''){
		$membership_no  = 0; 
		$member_name    = $_POST['member_name'];

	}  else {

		$membership_no  = $_POST['gaming_member_no']; 
		$member_name    = $_POST['gaming_old_member_name'];

	} 

		$bill_no = $_POST['gaming_billing_no'];

		$insert_data	 = array (
			'gaming_date'           			=> $_POST['gaming_billing_date'],
			'gaming_member_name'    			=> $member_name,
			'gaming_membership_no'    			=> $membership_no,
			'gaming_member_phone_number'        => $_POST['gaming_phone_number'],
			'gaming_sub_total'					=> $_POST['gaming_sub_tot'],	
			'gaming_discount' 					=> $_POST['after_gaming_discount'],
			'gaming_bill' 						=> $_POST['gaming_final_bill'],
			'was_bulid' 						=> 1,
			);  
		$wpdb->update($gaming_billing,$insert_data,array('gaming_bill_no' => $bill_no));
		$select_id_query="SELECT * from $gaming_billing where gaming_bill_no='$bill_no'";
		$select_id      = $wpdb->get_row( $select_id_query, OBJECT);
		$id=$select_id->id;
		var_dump($id);
		

		foreach ($_POST['group_team'] as $group_val ) {
		 		$gaming_relation_data 		= array(
		 				'gaming_id' 			=> $id,
		 				'gaming_no_of_members' 	=> $group_val['gaming_player'],
		 				'gaming_hours' 			=> $group_val['gaming_hours'],
		 				'gaming_total'		    => $group_val['gaming_total_value'],
		 			);
		 		$wpdb->insert( $gaming_billing_relation, $gaming_relation_data );

		 		
		 	}


		//Send mail to admin

		$emailid = 'sowmiya@ajnainfotech.com';
		$subject = 'Gaming Billing For '.$bill_no;
		$message = $member_name.' Paid '.$_POST['gaming_final_bill'].' Rupees';

		//Mail Function
		wp_mail( $emailid, $subject, $message );


		print('<script>window.location.href="admin.php?page=display_gaming&action=display_gaming&bill_no='.$bill_no.'&id='.$id.'"</script>');
				exit();
}
	$update_data = false;
   	$update_relation_data = false;
	


	if(isset($_POST['action']) AND $_POST['action'] == 'update_gaming_bill'  ) {

	$bill_no = $_POST['gaming_billing_no'];
	$id = $_GET['id'];

		$insert_data	 = array (
			'gaming_date'           			=> $_POST['gaming_billing_date'],
			'gaming_member_name'    			=> $_POST['gaming_old_member_name'],
			'gaming_membership_no'    			=> $_POST['gaming_member_no'],
			'gaming_member_phone_number'        => $_POST['gaming_phone_number'],
			'gaming_sub_total'					=> $_POST['gaming_sub_tot'],
			'gaming_discount' 					=> $_POST['after_gaming_discount'],
			'gaming_bill' 						=> $_POST['gaming_final_bill'],
			'was_bulid' 						=> 1,
			);  
		$wpdb->update($gaming_billing,$insert_data,array('gaming_bill_no' => $bill_no));
   		$relation_data_delete=$wpdb->update( $gaming_billing_relation,array( 'active' =>'0' ),array( 'gaming_id' => $id  ));

		foreach ($_POST['group_team'] as $group_val ) {
		 		$gaming_relation_data 		= array(
		 				'gaming_id' 			=> $id,
		 				'gaming_no_of_members' 	=> $group_val['gaming_player'],
		 				'gaming_hours' 			=> $group_val['gaming_hours'],
		 				'gaming_total'		    => $group_val['gaming_total_value'],
		 			);
		 		$wpdb->insert( $gaming_billing_relation, $gaming_relation_data);
		 		
		 	}

		 	//Send mail to admin

			$emailid = 'sowmiya@ajnainfotech.com';
			$subject = 'Updated In Gaming Billing For '.$bill_no;
			$message = $_POST['gaming_old_member_name'].' Paid '.$_POST['gaming_final_bill'].' Rupees';

			//Mail Function
			wp_mail( $emailid, $subject, $message );

		 	print('<script>window.location.href="admin.php?page=display_gaming&action=display_gaming&bill_no='.$bill_no.'&id='.$id.'"</script>');
				exit();
	}
	if(isset($_GET['action']) AND $_GET['action'] == 'update'  ) {

	$id  			= $_GET['id'];
	$query        	= "SELECT * FROM {$gaming_billing} WHERE active = 1 AND id ='$id'";
   	$update_data   	= $wpdb->get_row( $query, OBJECT );


	//relation table

	$relation_query              = "SELECT * FROM $gaming_billing_relation WHERE active = 1 AND gaming_id='$id'";
	$update_relation_data        = $wpdb->get_results($relation_query, OBJECT);



	}


?>
<style>

.billing_in {
    font-size: 16px;
    font-family: Arial;
    padding: 1px;
    float;left;
    padding: 24px;
}
.billing {
	color: #000000;
	font-family: Arial;
	margin-bottom:5px;
}
.billing_name input {
    width: 300px;
    height: 30px;

}

 #distributor_id {
   	display: none;
}
.billing label{
	float:left;
}
.billing_details{
	margin-left: 160px;
}
.billing_name_left input{
	width: 300px;
    height: 30px;

}
.billing_name_left{
	
    margin-left: 71%;
    margin-top: -30px;
}
.billing_name{
	height: 40px;
}
.gaming_new_user, .old_user_a_gaming{
	display: none;
}

.old_user_a_gaming, .new_user_a_gaming {
	cursor: pointer;
}

</style>
<section class="add-billing">
	<div class="">
		<div class="text-center">
			<div class="col-md-6 title">
				<h1>Gaming Billing</h1>
			</div>
		</div>
		<form class="form-horizontal" action="" method="POST" id="billing_form">
			<div class="billing_details">
				<div>
					<div class="billing_name">
						<span class="billing" style="padding: 8px 28px;"><label>Date : </label></span>
						<span class="billing_in"><input type="text" name="gaming_billing_date" id="gaming_billing_date" value="<?php 
						if( $_GET['action'] == 'update') { 
							echo $update_data->gaming_date;
						}
						else {
							echo $date; 
						}
						?>">
						</span>
					</div>
					<div class="billing_name_left">
						<span class="billing" style="padding: 8px 28px;"><label>Bill No : </label></span>
						<input type="text" name="gaming_billing_no" id="gaming_billing_no" class="gaming_billing_no" value="<?php echo $update_data->gaming_bill_no; ?>" readonly>

					</div>
				</div>
				<div class="billing_name">
					<span class="billing" style="padding: 8px 12px;"><label>Billing Type </label></span>
					<span class="billing_in">Gaming Billing</span>
				</div>
				<div class="billing_name">
					<span class="billing" style="padding: 1px;"><label>Member Name:</label></span>
					<span class="billing_in">

					<?php 
						if($_GET['action']=='update') {

							echo '<input type="text" name="gaming_old_member_name" id="gaming_old_member_name" value="'.$update_data->gaming_member_name.'" class="member_no">';

						} else{
						?>
						<select style="width: 300px;"  class="search_gaming_billing" name="search_gaming_billing" id="search_gaming_billing">
						</select>
						<input type="text" name="member_name" id="gaming_new_user" class="gaming_new_user">
						<input type="hidden" name="gaming_member_no" id="gaming_member_no" class="gaming_member_no">
						<input type="hidden" name="gaming_old_member_name" id="gaming_old_member_name" class="gaming_old_member_name">
						<a class="new_user_a_gaming">New User</a>
						<a class="old_user_a_gaming">Old User</a>
						<?php } ?>
					</span>
				</div>
				<div class="billing_name">
					<span class="billing" style="padding: 2px;"><label>Phone Number </label></span>
					<span class="billing_in"><input type="text" name="gaming_phone_number"  id="gaming_phone_number" value="<?php echo $update_data->gaming_member_phone_number; ?>"></span>
				</div>
			</div>			
			
			<div class="retail-repeater group_team">
			  	<div data-repeater-list="group_team" class="div-table">
				    <div class="div-table-row">
					    <div class="div-table-head sl-no">S.No</div>   
					    <div class="div-table-head ">No of members</div>
					    <div class="div-table-head ">Hours</div>
					    <div class="div-table-head ">Value</div>
					    <div class="div-table-head action">Bill Amout</div>
					   
					</div>
					<?php
						$i = 1;
						
							if($_GET['action'] == 'update') {

								foreach ($update_relation_data as $r_value ) {
									

						?>
					<div data-repeater-item class="repeterin div-table-row">
						<div class="div-table-col sale-rowno">
                            <div class="type-container">                               
                            </div>
                            <div class="rowno">1</div>
                        </div>
					     
					    <div class="div-table-col">
                            <div class="no_of_player player">
                            	<input type="text" name="gaming_player" id="gaming_player" value="<?php echo  $r_value ->gaming_no_of_members; ?>" class="gaming_player">
                            </div>
					    </div>
					    <div class="div-table-col">
                            <div class="hours player">
                            	<input type="text" name="gaming_hours" id="gaming_hours" value="<?php echo  $r_value ->gaming_hours; ?>" class="gaming_hours">
                            </div>
					    </div>
					    <div class="div-table-col">
                            <input type="hidden" name="gaming" id="gaming" class="gaming">
                            <div class="gaming player">
                            </div>
					    </div>
					    <div class="div-table-col">
					    	<input type="text" name="gaming_total_value" id="gaming_total_value" class="gaming_total_value" value="<?php echo $r_value->gaming_total; ?>" readonly />   
					    </div>  
			        </div>
			        
			        <?php
				        		$i++;
				        		}
				    		}
				    		else{ ?>

			    	<div data-repeater-item class="repeterin div-table-row">
						<div class="div-table-col sale-rowno">
                            <div class="type-container">                               
                            </div>
                            <div class="rowno">1</div>
                        </div>
					     
					    <div class="div-table-col">
                            <div class="no_of_player player">
                            	<input type="text" name="gaming_player" id="gaming_player" class="gaming_player">
                            </div>
					    </div>
					    <div class="div-table-col">
                            <div class="hours player">
                            	<input type="text" name="gaming_hours" id="gaming_hours" class="gaming_hours">
                            </div>
					    </div>
					    <div class="div-table-col">
                            <input type="hidden" name="gaming" id="gaming" class="gaming">
                            <div class="gaming player">
                            </div>
					    </div>
					    <div class="div-table-col">
					    	<input type="text" name="gaming_total_value" id="gaming_total_value" class="gaming_total_value" readonly />   
					    </div>  
			        </div>

			        <?php	
				    			}
				        ?>
			     </div>
			        <div class="div-table-row">
						<div class="div-table-col sale-rowno" style="width: 101px;">  </div>		                         			     
					    <div class="div-table-col" style="width: 653px;"></div>                            	    
					    <div class="div-table-col" style="width: 653px;"></div>                            	    
					    <div class="div-table-col" style="width: 162px;">Sub Total</div>  
					    <div class="div-table-col" style="width: 100px;">
					    	<input type="hidden" name="gaming_sub_tot" id="gaming_sub_tot" class="gaming_sub_tot">
                           	<div class="gaming_sub_tot">
							<?php 
                           	if($_GET['action'] == 'update'){
					    		echo $update_data ->gaming_sub_total; 

					    		} else {
					    			echo 0;
					    			}

                           	?>
                           	</div>                                                   
					    </div>  
			        </div>
			        <div class="div-table-row">
						<div class="div-table-col sale-rowno" style="width: 101px;">  </div>		                         			     
					    <div class="div-table-col" style="width: 653px;"></div>                            	    
					    <div class="div-table-col" style="width: 653px;"></div>                            	    
					    <div class="div-table-col" style="width: 162px;"> Discount(<span id="gaming_discount_per" class="gaming_discount_per"></span>)</div>  
					    <div class="div-table-col" style="width: 100px;">
					    	<input type="hidden" name="gaming_discount" id="gaming_discount" class="gaming_discount" value="
					    	<?php if($_GET['action'] == 'update' && $update_data->member_id != 0){
					    		echo 10;

					    		} else {
					    			echo 0;
					    			}
					    			?>">
					    	<input type="hidden" name="after_gaming_discount" id="after_gaming_discount" class="after_gaming_discount" value="<?php echo  $update_data ->gaming_discount;  ?>">
                           	<div class="gaming_discount" id="gaming_discount">
                           	<?php 
                           	if($_GET['action'] == 'update'){
					    		echo $update_data ->gaming_discount; 

					    		} else {
					    			echo 0;
					    			}

                           	?>
                           	</div>                                                   
					    </div>  
			        </div>
			        <div class="div-table-row">
						<div class="div-table-col sale-rowno" style="width: 101px;">  </div>	                         				     
					    <div class="div-table-col" style="width: 653px;"> </div>                           					    
					    <div class="div-table-col" style="width: 653px;"> </div>                           					    
					    <div class="div-table-col" style="width: 162px;">Total </div>                           
					    <div class="div-table-col" style="width: 100px;">
					    	<input type="hidden" name="gaming_final_bill" id="gaming_final_bill" class="gaming_final_bill">
                           	<div class="gaming_final_bill" id="gaming_final_bill">
							<?php 
                            	if(($_GET['action'])=='update'){
	 								echo  $update_data ->gaming_bill; 
								}else
								{
									echo 0;
								}
                            ?>
                           	</div>              	                           
					    </div>  
			        </div>
			   
			    <ul class="icons-labeled">
					<li>
						<a data-repeater-create href="javascript:void(0);" id="add_new_price_range">
						<span class="icon-block-color add-c"></span>Add Players</a>
					</li>
				</ul>
			 </div>
				
			<?php if(($_GET['action']) == 'update'){ ?>


			<input type="hidden" name="action" id="" value="update_gaming_bill"></br>
			<input type="submit" name="submit" id="submit" class="player_add" class="submit" value="Update">
			<?php } else { ?>

			<input type="hidden" name="action" id="" value="gaming_billing_submit"></br>
			<input type="submit" name="submit" id="submit" class="player_add" class="submit" value="Submit">
			<?php } ?>

		</form>
	</div>
</section>