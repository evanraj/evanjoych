
<?php
global $wpdb;
$lazertag_table = $wpdb->prefix. 'chaos_lazertag_billing';
$pricing       = $wpdb->prefix.'chaos_bill_princing';
if(isset($_GET['action']) AND $_GET['action'] == 'display_lazertag' ) {

	$bill_no  				= $_GET['bill_no'];
	$query        			= "SELECT * FROM {$lazertag_table} WHERE active = 1 AND lazertag_bill_no ='$bill_no'";

   	$update_data   			= $wpdb->get_row( $query, OBJECT ); 
   	$football_pricing_query = "SELECT * FROM {$pricing} WHERE active = 1";
   	$pricing_football   	= $wpdb->get_row( $football_pricing_query, OBJECT ); 


	} 
?>
 
<style>

.billing_in {
    font-size: 16px;
    font-family: Arial;
    padding: 1px;
    float;left;
    padding: 24px;
}
.billing {
	color: #000000;
	font-family: Arial;
	margin-bottom:5px;
}
.billing_name input {
    width: 300px;
    height: 30px;

}

 #distributor_id {
   	display: none;
}
.billing label{
	float:left;
}
.billing_details{
	margin-left: 160px;
}
.billing_name_left input{
	width: 300px;
    height: 30px;

}
.billing_name_left{
	
    margin-left: 71%;
    margin-top: -30px;
}
.billing_name{
	height: 40px;
}
.lazertag_new_user, .old_user_a_lazertag{
	display: none;
}

.old_user_a_lazertag, .new_user_a_lazertag {
	cursor: pointer;
}
.team{
	display: none;
	cursor: pointer;
}
.lazertag_hour_price,.lazertag_happyhours_div{
	display: none;
}
#lazertag_print{    
    margin-left: 94%;
    background-color: #0073aa;
    color: #fff;
    width: 84px;
    height: 40px;

    }
.add-billing{
	 margin-top: 106px;

}

</style>
<div calss="football_print">
	<input type="button" Name="lazertag_print" id="lazertag_print" value="Print" /> 
</div>
<section class="add-billing">
	<div class="">
		<div class="text-center">
			<div class="col-md-6 title">
				<h1>Lazertag Billing</h1>
			</div>
		</div>
		<form class="form-horizontal" action="" method="POST" id="billing_form">
			<div class="billing_details">
				<div>
					<div class="billing_name">
						<span class="billing" style="padding: 8px 28px;"><label>Date : </label></span>
						<span class="billing_in"><?php 
						
							echo $update_data->lazertag_date;
						
						?>
						</span>
					</div>
					<div class="billing_name_left">
						<span class="billing" style="padding: 8px 28px;"><label>Bill No : </label></span>
						<span id="lazertag_billing"><?php echo $update_data->lazertag_bill_no; ?></span>

					</div>
				</div>
				<div class="billing_name">
					<span class="billing" style="padding: 8px 12px;"><label>Billing Type </label></span>
					<span class="billing_in">Lazertag Billing</span>
				</div>
				<div class="billing_name">
					<span class="billing" style="padding: 1px;"><label>Member Name:</label></span>
					<span class="billing_in">

					<?php 
							echo $update_data->lazertag_member_name;
						?>
						
						
					</span>
				</div>
				<div class="billing_name">
					<span class="billing" style="padding: 2px;"><label>Phone Number </label></span>
					<span style="font-size: 16px;padding: 25px;"><?php echo $update_data->lazertag_member_phone_number; ?></span>
				</div>
				<div class="billing_name">
					<span class="billing" style="padding: 2px;"><label>Game Type </label></span>
					<span style="font-size: 16px;padding: 42px;;"><?php echo $update_data->gametype; ?></span>
				</div>
			</div>			
			
			<div class="group_team">
			  	<div data-repeater-list="group_team" class="div-table">
				    <div class="div-table-row">
					    <div class="div-table-head sl-no">S.No</div>   
					    <div class="div-table-head ">No of members/Team</div>
					    <div class="div-table-head ">Hours/Game</div>
					    <div class="div-table-head action">Bill Amout</div>
					   
					</div>
			    	<div data-repeater-item class="div-table-row">
						<div class="div-table-col sale-rowno">
                            <div class="type-container">                               
                            </div>
                            <div class="rowno">1</div>
                        </div>
					     
					    <div class="div-table-col">
                            <div class="no_of_player player">
                            	<?php echo $update_data->lazertag_players; ?>
                            	
                            </div>
					    </div>
					    <div class="div-table-col">
                            <div class="hours player">
                            	<?php echo $update_data->lazertag_hours; ?>
                            </div>
					    </div> 
					    <div class="div-table-col">
					    	<?php echo $update_data->lazertag_total;?>
					    </div>  
			        </div>
			   
			        <div class="div-table-row">
						<div class="div-table-col sale-rowno" style="width: 191px;">  </div>		                         			     
					    <div class="div-table-col" style="width: 706px;"></div>                            	                             	    
					    <div class="div-table-col" style="width: 425px;"> Discount(<span id="lazertag_discount_per" class="lazertag_discount_per"></span>)</div>  
					    <div class="div-table-col" style="width: 355px;">
					    	<?php 
										echo $update_data->lazertag_discount;
										
								 ?>
	                    </div>                                                   
					</div>  
			        <div class="div-table-row">
						<div class="div-table-col sale-rowno" style="width: 191px;">  </div>	                         				     
					    <div class="div-table-col" style="width: 706px;"> </div>                         					    
					    <div class="div-table-col" style="width: 425px;">Total </div>                           
					    <div class="div-table-col" style="width: 355px;">
					    	<?php  echo  $update_data ->lazertag_bill; 
								
		                    ?>
		                </div>              	                           
					</div> 
				</div>
			</div> 
		</form>
	</div>
</section>
