<?php
global $wpdb;
$gaming_table 				= $wpdb->prefix. 'chaos_gaming_billing';
$gaming_relation_data 		= $wpdb->prefix. 'chaos_gaming_billing_relation';
$pricing       				= $wpdb->prefix.'chaos_bill_princing';
if(isset($_GET['action']) AND $_GET['action'] == 'display_gaming'  ) {

	$bill_no  				= $_GET['bill_no'];
	$id      				= $_GET['id'];
	$query        			= "SELECT * FROM {$gaming_table} WHERE active = 1 AND gaming_bill_no ='$bill_no'";
   	$update_data   			= $wpdb->get_row( $query, OBJECT ); 

   	$relation_query    		= "SELECT * FROM {$gaming_relation_data} WHERE active = 1 AND gaming_id = '$id'";
   	$update_relational_data = $wpdb->get_results( $relation_query, OBJECT ); 

   	$football_pricing_query = "SELECT * FROM {$pricing} WHERE active = 1";
   	$pricing_football   	= $wpdb->get_row( $football_pricing_query, OBJECT ); 


	} 
?>
 
<style>
.add-billing{
	margin-top: 120px;
}

.billing_in {
    font-size: 16px;
    font-family: Arial;
    float;left;
    padding: 60px;
}
.billing {
	color: #000000;
	font-family: Arial;
	margin-bottom:5px;
}
.billing_name input {
    width: 300px;
    height: 30px;

}

 #distributor_id {
   	display: none;
}
.billing label{
	float:left;
	font-size: 16px;
}
.billing_details{
	   margin-left: 60px;
}
.billing_name_left input{
	width: 300px;
    height: 30px;

}
.billing_name_left{
	
    margin-left: 71%;
    margin-top: -30px;
}
.billing_name{
	height: 40px;
}
.new_user, .old_user_a{
	display: none;
}

.old_user_a, .new_user_a {
	cursor: pointer;
}
#gaming_print{    
            margin-left: 94%;
            background-color: #0073aa;
            color: #fff;
            width: 84px;
            height: 40px;

    }

</style>
<div calss="football_print">
<input type="button" Name="gaming_print" id="gaming_print" value="Print" /> 
</div>
<section class="add-billing">
	<div class="">
		<div class="text-center">
			<div class="col-md-6 title">
				<h1>Gaming Billing</h1>
			</div>
		</div>
		<form class="form-horizontal" action="" method="POST" id="billing_form">
			<div class="billing_details">
				<div>
					<div class="billing_name">
						<span class="billing" style="padding: 8px 36px;"><label>Date : </label></span>
						<span class="billing_in">
							<?php echo $update_data->gaming_date; ?>
						</span>
					</div>
					<div class="billing_name_left">
					<input type="hidden" value="<?php echo $id; ?>" name="gaming_id" id="gaming_id">
						<span class="billing"  style="padding: 9px 16px;"><label>Bill No : </label></span>
						<span id="gaming_bill_no"><?php echo $update_data->gaming_bill_no; ?></span>

					</div>
				</div>
				<div class="billing_name">
					<span class="billing" style="padding: 8px 16px;"><label>Billing Type </label></span>
					<span class="billing_in">Gaming Billing</span>
				</div>
				<div class="billing_name">
					<span class="billing" style="padding: 1px;"><label>Member Name:</label></span>
					<span class="billing_in">
					<?php echo $update_data->gaming_member_name; ?>						
					</span>
				</div>
				<div class="billing_name">
					<span class="billing" style="padding: 4px;"><label>Phone Number </label></span>
					<span class="billing_in">
						<?php echo $update_data->gaming_member_phone_number; ?>
					</span>
				</div>
			</div>			
			
			<div class=" ">
			  	<div data-repeater-list="" class="div-table">
				    <div class="div-table-row">
					    <div class="div-table-head sl-no">S.No</div>
					    <div class="div-table-head action">Number Of Members</div>
					    <div class="div-table-head action">Hours</div>
					    <div class="div-table-head action">Bill Amout</div>
					   
					</div>
					<?php
						$i = 1;
						
							if($update_relational_data) {

								foreach ($update_relational_data as $r_value ) {
									

						?>
					<div data-repeater-item class="repeterin div-table-row">
						<div class="div-table-col sale-rowno">
                            <div class="type-container">                               
                            </div>
                            <div class="rowno">1</div>
                        </div>
					     
					    <div class="div-table-col">
                            <div class="no_of_player player">
                            	<?php echo  $r_value ->gaming_no_of_members; ?>
                            </div>
					    </div>
					    <div class="div-table-col">
                            <div class="hours player">
                            	<?php echo  $r_value ->gaming_hours; ?>
                            </div>
					    </div>

					    <div class="div-table-col">
                           <div class="gaming_total_value" id="gaming_total_value">
                            	<?PHP echo $r_value ->gaming_total; ?>
                            </div>
					    </div>  
			        </div>
			        
			        <?php
				        		$i++;
				        		}
				    		} ?>

			        <div data-repeater-item class="repeterin div-table-row">
						<div class="div-table-col sale-rowno">  </div>		                         			     
					    <div class="div-table-col"></div>                            	    
					    <div class="div-table-col">Sub Total</div>  
					    <div class="div-table-col">
                           	<div class="discount" id="discount">
	                           	<?php 
		 							echo  $update_data ->gaming_sub_total; 
							
	                            ?>
                           	</div>                                                   
					    </div>  
			        </div>
					<div data-repeater-item class="repeterin div-table-row">
						<div class="div-table-col sale-rowno">  </div>		                         			     
					    <div class="div-table-col"></div>                            	    
					    <div class="div-table-col"> Discount(<span id="discount_per" class="discount_per"></span>)</div>  
					    <div class="div-table-col">
                           	<div class="discount" id="discount">
	                           	<?php 
		 							echo  $update_data ->gaming_discount; 
							
	                            ?>
                           	</div>                                                   
					    </div>  
			        </div>
			        <div data-repeater-item class="repeterin div-table-row">
						<div class="div-table-col sale-rowno">  </div>	                         				     
					    <div class="div-table-col"> </div>                           					    
					    <div class="div-table-col">Total </div>                           
					    <div class="div-table-col">
					    	<input type="hidden" name="final_bill" id="final_bill" class="final_bill" value="<?php $update_data ->ft_football_bill; ?>">
                           	<div class="final_bill" id="final_bill">
							<?php                            	
	 								echo  $update_data ->gaming_bill; 
                            ?>
                           	</div>              	                           
					    </div>  
			        </div>
			    </div>
			</div>
		</form>
	</div>
</section>