jQuery(document).ready(function () {

    jQuery('.retail-repeater').repeater({
        defaultValues: {

        },
        show: function () {console.log('dfdf')
            var count = 1;
            jQuery('.retail-repeater .repeterin').each(function(){
                jQuery(this).find('.rowno').text(count);
                count++;
            });
            jQuery(this).slideDown();

            populateSelect(jQuery(this).find('.search_player'));

        },
        hide: function (deleteElement) {
            if(confirm('Are you sure you want to delete this element?')) {
                jQuery(this).slideUp(deleteElement);

                var count = 1;
                jQuery('.retail-repeater .repeterin').each(function(){ 
                    jQuery(this).find('.rowno').text(count);
                    count++;
                });
            }
        },
        ready: function (setIndexes) {
            
        }
    });
    populateSelect(jQuery(".search_player"));



    jQuery('.team-edit').on('click', function(){
        window.location.replace('admin.php?page=add_team&action=get_team&team_id='+jQuery(this).attr('data-teamid'));
    });

    jQuery('.date_pic').datepicker({
        dateFormat: 'yy-mm-dd'
    });













    jQuery('.matches-repeater').repeater({
        defaultValues: {
            team1 : 0,
            team2 : 0,
            match_id : 0
        },
        show: function () {
            var count = 1;
            jQuery('.matches-repeater .repeterin').each(function(){
                jQuery(this).find('.rowno').text(count);
                count++;
            });
            jQuery(this).slideDown();

            removeSchedule(this)
            populateDragable();
            populateCalender();

        },
        hide: function (deleteElement) {
            if(confirm('Are you sure you want to delete this element?')) {
                jQuery(this).slideUp(deleteElement);

                var count = 1;
                jQuery('.matches-repeater .repeterin').each(function(){ 
                    jQuery(this).find('.rowno').text(count);
                    count++;
                });
            }
        },
        ready: function (setIndexes) {
            populateCalender();
        }
    });




    jQuery(".select_team").select2().on("select2:select", function (e) {
        jQuery('.teams_in').append('<div class="draggable" data-teamid="'+e.params.data.id+'"><div class="team-txt">'+e.params.data.text+'</div><div class="team-close">x</div><div class="clear"></div></div>')
        populateDragable();
    }).on("select2:unselecting", function(e){

        jQuery('.sortable-css').find("[data-teamid='" + e.params.args.data.id + "']").parent().find('.vs_team').val(0);

        jQuery('.teams_in').find("[data-teamid='" + e.params.args.data.id + "']").remove();
        jQuery('.sortable-css').find("[data-teamid='" + e.params.args.data.id + "']").remove();

        jQuery('.no-sortable').each(function(){
            if(jQuery(this).find('.draggable').length == 0) {
                jQuery(this).addClass('sortable').removeClass('no-sortable');
            }

        })

        populateDragable();
    });


    //Remove a Team from Shedule
    jQuery('.team-close').live('click', function(){
        if(confirm("Press a button!")) {

            jQuery(this).parent().parent().find('.vs_team').val(0)

            jQuery(this).parent().parent().removeClass('no-sortable').addClass('sortable')
            jQuery(this).parent().remove();
            //jQuery(this).parent().parent().addClass('sortable');
            populateDragable();
        }
    });


    populateDragable();
});















    function removeSchedule(selector = '') {
        console.log(jQuery(selector).find('.ui-draggable').remove());
        console.log(jQuery(selector).find('.sortable-css').addClass('sortable').removeClass('no-sortable'));
    }


    function populateCalender(){
        jQuery('.date_pic_r').datepicker({
            dateFormat: 'yy-mm-dd'
        });
    }


    function populateDragable(){
        jQuery( ".sortable" ).sortable({
            revert: true,
            update: function(event, ui) {
                jQuery(this).removeClass('sortable').addClass('no-sortable');
                jQuery(this).find('.vs_team').val(jQuery(this).find('.draggable').attr('data-teamid'))
            }
        });


        jQuery( ".draggable" ).draggable({
            connectToSortable: ".sortable",
            helper: "clone",
            revert: "invalid",
            drag: function (event, ui) {

            },
            stop: function (event, ui) {
                console.log('droped')
            }
        });
        jQuery( "ul, li" ).disableSelection();

    }



    function formatCustomerNamea (state) {
        if (!state.id) {
            return state.id;
        }
        var $state = jQuery(
        '<span>' +
          state.name +
        '</span>'
        );
        return $state;
    };

    function formatCustomerNameb (state) {
        if (!state.id) {
            return state.id;
        }
        var $state = jQuery(
        '<span>' +
          state.name +
        '</span>'
        );
        return $state;
    };


    function populateSelect($selector) {
        $selector.select2({
            width: '200px',
            multiple: false,
            minimumInputLength: 1,
            allowClear: true,
            placeholder: "Search Lot Number",

            ajax: {
                type: 'POST',
                url: frontendajax.ajaxurl,
                delay: 250,
                dataType: 'json',
                data: function(params) {
                    return {
                        action: 'searchPlayer', // search term
                        page: 1,
                        search_key: params.term,
                    };
                },
                processResults: function(data) {
                    var results = [];

                    return {
                        results: jQuery.map(data.items, function(obj) {
                            return { id: obj.id, name:obj.name, phone:obj.phone};
                        })
                    };
                },
                cache: true,
            },
            initSelection: function (element, callback) {
                callback({ id: jQuery(element).attr('data-teamid'), name: jQuery(element).attr('data-teamname'), phone:jQuery(element).attr('data-teamphone') });
            },
            templateResult: formatCustomerNamea,
            templateSelection: formatCustomerNamea
        }).on("select2:unselecting", function(e) {
            jQuery(this).parent().parent().find('.player_phone').text('');
        }).on("select2:select", function(e) {
            jQuery(this).parent().parent().find('.player_phone').text(e.params.data.phone);
        });
    }