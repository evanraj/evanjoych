<?php
if(isset($_GET['pagess']) && $_GET['pagess']=='1' ){
	include get_template_directory() .'/inc/admin/billing/views/lazertag/lazertag_second.php';
} 
else if($_GET['pagess']=='2' ){
	include get_template_directory() .'/inc/admin/billing/views/lazertag/lazertag_member_setting.php';
}
else if($_GET['pagess']=='3' ){
	include get_template_directory() .'/inc/admin/billing/views/lazertag/lazertag_billing.php';
}
else if($_GET['pagess']=='4' ){
	include get_template_directory() .'/inc/admin/billing/views/lazertag/display_lazertag_billing.php';
}
else {
?>
<div class="package">
	<div class="" style="padding:25px;margin-left:40%;">
		<label class="btn btn-success birthday_package">Birthday Packages</label>
	</div>
	<div class="" style="padding:25px;margin-left:40%;">
		<label class="btn btn-success corporate_package">Corporate Packages</label>
	</div>
	<div class="" style="padding:25px;margin-left:40%;">
		<label class="btn btn-success console_gaming">Console Gaming</label>
	</div>
	<div class="" style="padding:25px;margin-left:40%;">
		<label class="btn btn-success virtual_reality_gaming">Virtual Reality Gaming</label>
	</div>
	<div class="" style="padding:25px;margin-left:40%;">
		<label class="btn btn-success motion_gaming">Motion Sensor Gaming</label>
	</div>

	<!-- <div class="" style="padding:25px;margin-left:40%;">
		<label class="btn btn-success normal_gaming">Normal Billing</label>
	</div> -->
</div>
<?php }
?>

<script type="text/javascript">
jQuery(document).ready(function(){
	jQuery('.console_gaming').on('click change',function(){
		jQuery.ajax({
			method:"POST",
			dataType : 'json',
			url : frontendajax.ajaxurl,
			data : {
				action 		: 'gaming_type',
				value  		: 'console',
			},
			success:function (data){
			   if(data.redirect != 0) { 
                    setTimeout(function() {
                        managePopupContent(data);
                    }, 0);
                }
			}
		});
	});
	jQuery('.corporate_package').on('click change',function(){
		alert('corporate_package');
	});
	jQuery('.normal_gaming').on('click change',function(){
		alert('normal_gaming');
	});
});
</script>