
<?php
if(isset($_GET['pagess']) && $_GET['pagess']=='1' ){
	include get_template_directory() .'/inc/admin/billing/views/football_price_setting.php';
} 
else if($_GET['pagess']=='2' ){
	include get_template_directory() .'/inc/admin/billing/views/football_member_setting.php';
}
else if($_GET['pagess']=='3' ){
	include get_template_directory() .'/inc/admin/billing/views/football_billing.php';
}
else if($_GET['pagess']=='4' ){
	include get_template_directory() .'/inc/admin/billing/views/display_football_billing.php';
}
else{

?>


<STYLE TYPE="text/css">
.time_section,.morning_session,.evening_session{
	padding: 10px;
	/*margin-left: 20%;*/
}
/*.btn-success,.btn-success.active,.btn-success.focus,.btn-success:hover,.btn-danger.active,.btn-danger.focus,.btn-danger,.btn-danger:hover{
background-color: #3a3eb1;
}
.btn-success.active:focus,.btn-success.active:hover,.btn-danger.active:focus,.btn-danger.active:hover{
	background-color: #4c09ec;
}*/

</STYLE>
<div class="container-fluid">
	<div class="row">
		<section class="time_section">
			<div>
<!-- 

						<div>
							<p id="datepairExample">
							    <input type="text" class="date start" />
							    <input type="text" class="time start" /> to
							    <input type="text" class="time end" />
							    <input type="text" class="date end" />
							</p>
						</div>




 -->




				<div class="morning_session1">
					<div class="morning_session" data-toggle="buttons">
						<lable>Morning Session</lable>
						
						<label class="btn btn-success"> 
						 	<input type="checkbox" autocomplete="off" name="action"  class="first-session"  value="morning"> 3 AM - 3 PM
						</label> 	
					</div>
					<div class="morning_timing" style="display: none;">
						<input type="button" name="timing"  class="btn btn-danger one_or_more one"  value="One Hour">
						<input type="button" name="timing"  class="btn btn-danger one_or_more more"  value="More Than One Hour"> 
					</div>
					<div class="morning-more-than-one"  style="display: none;margin-top: 10px;">
						<div>
							<p id="basicExample">
							    From : 
							    	<input type="text" class="date start" />
							    	<input type="text" class="time start" /> 
							    To:
							    	<input type="text" class="time1 end" />
							    	<input type="text" class="date1 end" />
							</p>
						</div>
						<input type="buttons" data-session="morning_session" style="background-color:#449c44;" class="btn btn-success time_value" name="time_value" value="Submit" readonly/>
					</div>
					<div class="btn-group morning-one-hour" data-toggle="buttons" style="display:none;margin-top: 10px;">
						 <label class=""> 
						 	<input type="button" autocomplete="off"  class="session btn btn-success" data-session = "morning_session" value="3am-4am"/>
						 </label> 
						 <label class=""> 
						 	<input type="button" autocomplete="off"  class="session btn btn-success" data-session = "morning_session" value="4am-5am"/>
						 </label> 
						 <label class=""> 
						 	<input type="button" autocomplete="off"  class="session btn btn-success" data-session = "morning_session" value="5am-6am"/>
						 </label>
						  <label class=""> 
						  	<input type="button" autocomplete="off"  class="session btn btn-success" data-session = "morning_session" value="6am-7am"/>
						 </label>
						 <label class=""> 
						 	<input type="button"  autocomplete="off"  class="session btn btn-success" data-session = "morning_session" value="7am-8am"/>
						 </label>
						  <label class=""> 
						  	<input type="button" autocomplete="off"  class="session btn btn-success" data-session = "morning_session" value="8am-9am"/>
						 </label>
						 <label class=""> 
						 	<input type="button" autocomplete="off"  class="session btn btn-success" data-session = "morning_session" value="9am-10am"/>  
						 </label>
						  <label class=""> 
						  	<input type="button" autocomplete="off"  class="session btn btn-success" data-session = "morning_session" value="10am-11am"/>
						 </label> 
						 <label class=""> 
						 	<input type="button" autocomplete="off"  class="session btn btn-success" data-session = "morning_session" value="11am-12am"/>
						 </label> 
						 <label class=""> 
						 	<input type="button" autocomplete="off"  class="session btn btn-success" data-session = "morning_session" value="12pm-1pm"/>
						 </label>
						  <label class=""> 
						  	<input type="button" autocomplete="off"  class="session btn btn-success" data-session = "morning_session" value="1pm-2pm"/>
						 </label>
						  <label class=""> 
						  	<input type="button" autocomplete="off"  class="session btn btn-success" data-session = "morning_session" value="2pm-3pm"/>
						 </label> 
			 		</div>
				</div>
				
			 	<div class="evening_session1">
				 	<div class="evening_session" data-toggle="buttons" >
				 		<lable>Evening Session</lable>
						<label class="btn btn-success" > 
						 	<input type="checkbox" autocomplete="off" name="action"  class="first-session"  value="evening"> 3 PM - 3 AM
						</label> 	
					</div>
					<div class="evening_timing" style="display: none;">
						<input type="button" name="timing"  class="btn btn-danger eve_one_or_more eve_one"  value="One Hour">
						<input type="button" name="timing"  class="btn btn-danger eve_one_or_more eve_more"  value="More Than One Hour"> 
					</div>
					<div class="eve-more-than-one" style="display: none;margin-top: 10px;">
						<div>
							<p id="basicExample">
							    From : 
							    	<input type="text" class="eve_date start" />
							    	<input type="text" class="eve_time start" /> 
							    To:
							    	<input type="text" class="eve_time1 end" />
							    	<input type="text" class="eve_date1 end" />
							</p>
						</div>
						<input type="submit" data-session="evening_session" style="background-color:#5bc0de;" class="btn btn-success eve_time_value" name="time_value" value="Submit"></button>
					</div>
				 	<div class="btn-group eve-one-hour" data-toggle="buttons" style="display:none;margin-top: 10px;">
				 		<label class=""> 
				 			<input type="button" autocomplete="off"  class="session btn btn-success" data-session = "evening_session" value="3pm-4pm"/>
						 </label>
						 <label class=""> 
						 	<input type="button" autocomplete="off"  class="session btn btn-success" data-session = "evening_session" value="4pm-5pm"/>
						 </label>
						 <label class=""> 
						 	<input type="button" autocomplete="off"  class="session btn btn-success" data-session = "evening_session" value="5pm-6pm"/>
						 </label>
						  <label class=""> 
						  	<input type="button" autocomplete="off"  class="session btn btn-success" data-session = "evening_session" value="6pm-7pm"/>
						 </label>
						  <label class=""> 
						  	<input type="button" autocomplete="off"  class="session btn btn-success" data-session = "evening_session" value="7pm-8pm"/>
						 </label>
						  <label class=""> 
						  	<input type="button" autocomplete="off"  class="session btn btn-success" data-session = "evening_session" value="8pm-9pm"/>
						 </label>
						  <label class=""> 
						  	<input type="button" autocomplete="off"  class="session btn btn-success" data-session = "evening_session" value="9pm-10pm"/>
						 </label>
						  <label class=""> 
						  	<input type="button" autocomplete="off"  class="session btn btn-success" data-session = "evening_session" value="10pm-11pm"/>
						 </label> 
						 <label class=""> 
						 	<input type="button" autocomplete="off"  class="session btn btn-success" data-session = "evening_session" value="11pm-12pm"/>
						 </label>
						  <label class=""> 
						  	<input type="button" autocomplete="off"  class="session btn btn-success" data-session = "evening_session" value="12pm-1am"/>
						 </label> 
						 <label class=""> 
						 	<input type="button" autocomplete="off"  class="session btn btn-success" data-session = "evening_session" value="1am-2am"/>
						 </label>
						 <label class=""> 
						 	<input type="button" autocomplete="off"  class="session btn btn-success" data-session = "evening_session" value="2am-3am"/>
						</lable>
				 	</div>
				 </div>
			</div>
		</section>
	</div>	
</div>

<script type="text/javascript">
jQuery(document).ready(function(){

	jQuery('#basicExample .time').timepicker({
        'showDuration': true,
        'timeFormat': 'g:ia'
    });

    jQuery('#basicExample .date').datepicker({
        'dateFormat': 'mm/dd/yy',
        'autoclose': true
    });


    jQuery('#basicExample .time1').timepicker({
        'showDuration': true,
        'timeFormat': 'g:ia'
    });

    jQuery('#basicExample .eve_date1').datepicker({
        'dateFormat': 'mm/dd/yy',
        'autoclose': true
    });
    	jQuery('#basicExample .eve_time').timepicker({
        'showDuration': true,
        'timeFormat': 'g:ia'
    });

    jQuery('#basicExample .eve_date').datepicker({
        'dateFormat': 'mm/dd/yy',
        'autoclose': true
    });


    jQuery('#basicExample .eve_time1').timepicker({
        'showDuration': true,
        'timeFormat': 'g:ia'
    });

    jQuery('#basicExample .date1').datepicker({
        'dateFormat': 'mm/dd/yy',
        'autoclose': true
    });

	jQuery('#basicExample').datepair({
	    parseDate: function(input){
	        var picker = jQuery(input).data('pikaday');
	        return picker.getDate();
	    },
	    updateDate: function(input, dateObj){
	        var picker = jQuery(input).data('pikaday');
	        return picker.setDate(dateObj);
	    }
	});
    //initialize datepair
    var basicExampleEl = document.getElementById('basicExample');
    var datepair = new Datepair(basicExampleEl);

	// jQuery('#stepExample1').timepicker({ 'step': 15 });
	// jQuery('#stepExample2').timepicker({ 'step': 15 })
	jQuery('.first-session').live('click change',function(){
	  var session_val = jQuery('.first-session:checked').val();
	  if(session_val == "morning"){
	    jQuery('.evening_session').css('display','none');
	    jQuery('.morning_timing').css('display','block');
	    jQuery('.evening_timing').css('display','none');
	  } else if(session_val == "evening"){
	    jQuery('.morning_session').css('display','none');
	    jQuery('.morning_timing').css('display','none');
	    jQuery('.evening_timing').css('display','block');
	  } else{
	  	console.log("ok");
	  }

	});

	jQuery('.one_or_more').click(function(){
		var player = jQuery(this).val();
		if(player == "One Hour"){
			jQuery('.more').css('display','none');
			jQuery('.morning-one-hour').css('display','block');
		} else if( player == "More Than One Hour" ){
			jQuery('.one').css('display','none');
			jQuery('.morning-more-than-one').css('display','block');
		} else{
			console.log("ok");
		}
	});
	jQuery('.eve_one_or_more').click(function(){
		var player = jQuery(this).val();
		if(player == "One Hour"){
			jQuery('.eve_more').css('display','none');
			jQuery('.eve-one-hour').css('display','block');
		} else if( player == "More Than One Hour" ){
			jQuery('.eve_one').css('display','none');
			jQuery('.eve-more-than-one').css('display','block');
		} else{
			console.log("ok");
		}
	});
	jQuery('.session').live('click change',function(){
		var buttons_val = jQuery(this).val();
		var session_timing = jQuery(this).data('session');

		jQuery.ajax({
			method:"POST",
			dataType : 'json',
			url : frontendajax.ajaxurl,
			data : {
				action :'move_to_price',
				value  : buttons_val,
				session : session_timing,
				from : '',
				to : '',
				from_date : '',
				to_date : '',
			},
			success:function (data){
			   	if(data.redirect != 0) { 
                    setTimeout(function() {
                        managePopupContent(data);
                    }, 0);
                }
			}
		});
		
	});

	jQuery('.time_value').on('click change',function(){
		var time_value_from = jQuery('.time').val();
		var time_value_to   = jQuery('.time1').val();
		if(time_value_from == '' && time_value_to == ''){
			alert("Enter From and To timing!!!");
		} else{
		var session_timing  = jQuery(this).data('session');
		jQuery.ajax({
			method:"POST",
			dataType : 'json',
			url : frontendajax.ajaxurl,
			data : {
				action 		:'move_to_price',
				value  		: '',
				session 	: session_timing,
				from 		: time_value_from,
				to 			: time_value_to,
				from_date 	: jQuery('.date').val(),
				to_date 	: jQuery('.date1').val(),
			},
			success:function (data){
			   if(data.redirect != 0) { 
                    setTimeout(function() {
                        managePopupContent(data);
                    }, 0);
                }
			}
		});	
		}		
	});

	jQuery('.eve_time_value').on('click',function(){
		var time_value_from = jQuery('.eve_time').val();
		var time_value_to   = jQuery('.eve_time1').val();
		if(time_value_from == '' && time_value_to == ''){
			alert("Enter From and To timing!!!");
		} else{
		var session_timing  = jQuery(this).data('session');
		jQuery.ajax({
			method:"POST",
			dataType : 'json',
			url : frontendajax.ajaxurl,
			data : {
				action 		:'move_to_price',
				value  		: '',
				session 	: session_timing,
				from 		: time_value_from,
				to 			: time_value_to,
				from_date 	: jQuery('.eve_date').val(),
				to_date 	: jQuery('.eve_date1').val(),
			},
			success:function (data){
			   if(data.redirect != 0) { 
                    setTimeout(function() {
                        managePopupContent(data);
                    }, 0);
                }
			}
		});	
		}		
	});
});
</script>
<?php } ?>