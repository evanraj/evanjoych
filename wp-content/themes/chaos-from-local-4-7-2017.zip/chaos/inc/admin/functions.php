<?php 
require get_template_directory() . '/inc/admin/menu-functions.php';
require get_template_directory() . '/inc/admin/team/pagination-functions.php';
require get_template_directory() . '/inc/admin/team/functions/ajax-functions.php';


/*Sowmiya*/
//for utility manager
require get_template_directory() . '/inc/admin/utility-manager/pagination-functions.php';
//for Football Billing
require get_template_directory() . '/inc/admin/billing/pagination-functions.php';


/*Evan*/
require get_template_directory() . '/inc/admin/chaos_members/functions/ajax-functions.php';
require get_template_directory() . '/inc/admin/chaos_members/pagination-functions.php';



function my_footer_shh() {
  remove_filter( 'update_footer', 'core_update_footer' ); 

  remove_submenu_page( 'index.php', 'update-core.php' );
  remove_menu_page( 'jetpack' );                    //Jetpack* 
  remove_menu_page( 'edit.php' );                   //Posts
  remove_menu_page( 'upload.php' );                 //Media
  remove_menu_page( 'edit.php?post_type=page' );    //Pages
  remove_menu_page( 'edit-comments.php' );          //Comments
  //remove_menu_page( 'themes.php' );                 //Appearance
  remove_menu_page( 'plugins.php' );                //Plugins
  remove_menu_page( 'users.php' );                  //Users
  remove_menu_page( 'tools.php' );                  //Tools
  remove_menu_page( 'options-general.php' );        //Settings
}
add_action( 'admin_menu', 'my_footer_shh' );




add_action( 'admin_enqueue_scripts', 'custom_wp_admin_scripts' );
function custom_wp_admin_scripts() {
	wp_enqueue_style( 'admin-style', get_template_directory_uri() . '/inc/admin/css/admincss.css' );

	wp_enqueue_style( 'src-select2', get_template_directory_uri() . '/inc/admin/js/select2/dist/css/select2.min.css' );  
	wp_enqueue_script( 'src-select2', get_template_directory_uri() . '/inc/admin/js/select2/dist/js/select2.full.min.js', array('jquery'), false, false );
	
	wp_enqueue_script( 'repeater', get_template_directory_uri() . '/inc/admin/js/jquery.repeater.js', array('jquery'), false, false );

	wp_enqueue_script('jquery-ui-datepicker');
	wp_enqueue_style('jquery-ui-css', 'http://code.jquery.com/ui/1.8.24/themes/blitzer/jquery-ui.css');
	

	wp_enqueue_script( 'ui-script',  get_template_directory_uri() . '/inc/admin/js/jquery-ui.js', array('jquery'), false, false );


	wp_enqueue_script( 'admin-script',  get_template_directory_uri() . '/inc/admin/js/script.js', array('jquery'), false, false );
	wp_localize_script( 'admin-script', 'frontendajax', array( 'ajaxurl' => admin_url( 'admin-ajax.php' )));



  //utility Style,Scripts,Popup and datepicker
  wp_enqueue_script( 'utility', get_template_directory_uri() . '/inc/admin/utility-manager/js/utility.js', array ( 'jquery' ), true, false);
  wp_enqueue_script( 'bpopup', get_template_directory_uri() . '/inc/admin/utility-manager/js/jquery.bpopup.min.js', array ( 'jquery' ), true, false);
  wp_enqueue_script( 'easing', get_template_directory_uri() . '/inc/admin/utility-manager/js/jquery.easing.1.3.js', array ( 'jquery' ), true, false);
    //Billing Js
  wp_enqueue_script( 'billing', get_template_directory_uri() . '/inc/admin/billing/js/billing.js', array ( 'jquery' ), true, false);
 //Create Site URL for Print Function
  wp_localize_script( 'billing', 'printajax', array( 'internalprint' => site_url( '' )));
 
  wp_enqueue_script('jquery');
  wp_enqueue_script('jquery-ui-core');
  wp_enqueue_script('jquery-ui-datepicker');
  wp_enqueue_style('jquery-ui-css', 'http://code.jquery.com/ui/1.8.24/themes/blitzer/jquery-ui.css');

}

function searchPlayer($search = ''){

	global $wpdb;
	$customer_name = $_POST['search_key'];

	$member_table = $wpdb->prefix. 'chaos_members';
	$query = "SELECT * FROM {$member_table} WHERE  name LIKE '".$customer_name."%' AND active = 1";
	$data['items'] =  $wpdb->get_results( $query );
	echo json_encode($data);
	die();
}
add_action( 'wp_ajax_searchPlayer', 'searchPlayer' );
add_action( 'wp_ajax_nopriv_searchPlayer', 'searchPlayer' );

function getTeams(){

	global $wpdb;
	$football_team = $wpdb->prefix. 'chaos_football_team';
	$relation_team = $wpdb->prefix. 'chaos_football_team_relation';

	$query = "SELECT tot.*, SUM(tot.is_membar) as mem_count from (SELECT ft.id, ft.team_name, ft.active as team_active, (CASE WHEN ftr.active is NULL THEN 1 ELSE ftr.active END ) as relation_active, (CASE WHEN ftr.active is NULL THEN 0 ELSE 1 END ) as is_membar FROM ${football_team} ft LEFT JOIN ${relation_team} ftr ON ft.id = ftr.team_id ) tot WHERE tot.relation_active = 1 AND tot.team_active = 1 GROUP BY tot.id";
	$teams = $wpdb->get_results( $query );

	return $teams;
}

function get_team_detail($team_id = '') {

	global $wpdb;
	$football_team = $wpdb->prefix. 'chaos_football_team';
	$query = "SELECT * FROM ${football_team} WHERE active = 1 AND id=".$team_id;
	$data['team_data'] =  $wpdb->get_row( $query ) ;

	$data['members_data'] = false;
	if($data['team_data']) {
		$team_relation = $wpdb->prefix. 'chaos_football_team_relation';
		$chaos_members = $wpdb->prefix. 'chaos_members';

		$members_query = "SELECT m.id, m.name, m.phone FROM ${team_relation} tr JOIN ${chaos_members} m ON tr.member_id = m.id WHERE tr.active = 1 AND m.active = 1 AND tr.team_id = ${team_id}";
		$data['members_data'] =  $wpdb->get_results( $members_query );
	}
	return $data;
}


function getTournamentDetail($tournament_id = 0) {
	global $wpdb;
	$tournament_table = $wpdb->prefix. 'chaos_tournaments';
	$query = "SELECT * FROM ${tournament_table} WHERE active = 1 AND id=".$tournament_id;
	return $wpdb->get_row( $query );
}
function getTournamentTeams($tournament_id = 0, $active = 1) {
	global $wpdb;
	$tournament_teams_table = $wpdb->prefix. 'chaos_tournament_teams';
	$teams_table = $wpdb->prefix. 'chaos_football_team';
	if($active == 1) {
		$query = "SELECT tt.*, t.team_name FROM ${tournament_teams_table} as tt JOIN ${teams_table} as t ON tt.team_id = t.id WHERE tt.active = ${active} AND tt.tournament_id=".$tournament_id;
	} else {
		$query = "SELECT tt.*, t.team_name FROM ${tournament_teams_table} as tt JOIN ${teams_table} as t ON tt.team_id = t.id WHERE tt.tournament_id=".$tournament_id;
	}

	return $wpdb->get_results( $query, ARRAY_A );
}
function getTournamentSchedule($tournament_id = 0) {
	global $wpdb;
	$tournament_teams_table = $wpdb->prefix. 'chaos_tournament_schedule';
	$teams_table = $wpdb->prefix. 'chaos_football_team';
	$query = "SELECT *, (SELECT team_name from ${teams_table} as t WHERE t.id = ts.team1 ) as team1_name, (SELECT team_name from ${teams_table} as t WHERE t.id = ts.team2 ) as team2_name FROM ${tournament_teams_table} as ts WHERE active = 1 AND ts.tournament_id=".$tournament_id." ORDER BY ts.match_order ASC";

	return $wpdb->get_results( $query );
}


function getMatchDetails($match_id = 0){
	global $wpdb;
	$match_table = $wpdb->prefix. 'chaos_tournament_schedule';
	$team_table = $wpdb->prefix. 'chaos_football_team';

	$query = "SELECT *, (SELECT team_name from ${team_table} as t WHERE t.id = ts.team1 ) as team1_name, (SELECT team_name from ${team_table} as t WHERE t.id = ts.team2 ) as team2_name, (SELECT team_name from wp_chaos_football_team as t WHERE t.id = ts.winner ) as winner_team, (SELECT team_name from wp_chaos_football_team as t WHERE t.id = ts.loser ) as loser_team FROM ${match_table} as ts WHERE active = 1 AND ts.id=${match_id} ORDER BY ts.match_order ASC";
 
	return $wpdb->get_row( $query );
}
















/*Sowmiya*/

//Utility Manager
function utility_manager(){

include( get_template_directory().'/inc/admin/utility-manager/ajax/listing-template/list_utility.php' );
  die();
}
add_action( 'wp_ajax_utility_manager', 'utility_manager' );
add_action( 'wp_ajax_nopriv_utility_manager', 'utility_manager' );

//Popup Utility Manager
function popup_utility(){
  include( get_template_directory().'/inc/admin/utility-manager/ajax/utility_popup.php' );
  die();
}
add_action( 'wp_ajax_popup_utility','popup_utility' );
add_action( 'wp_ajax_nopriv_popup_utility','popup_utility' );

//Utility Status
function utility_status(){
	global $wpdb;
  	$status =$_POST['status'];
  	$id =$_POST['id'];
  	if(isset($_POST['postponed_days'])){
  		$postponed_days = $_POST['postponed_days'];
  	}
  	else{
  		$postponed_days=0;
  	}


  	$user_table = $wpdb->prefix.'chaos_utility';
  	$utility_details = $wpdb->prefix.'chaos_utility_details';

    if($status != 'postponed') {
      $nxt_utility_query = "SELECT (CASE
        WHEN ut_periods = 'w'
        THEN DATE(ut_utillity_date + INTERVAL (ut_duration) WEEK )
        ELSE DATE(ut_utillity_date + INTERVAL (ut_duration) MONTH )
        END ) as next_pay_date FROM wp_chaos_utility WHERE id = ".$id;
      $nxt_utility = $wpdb->get_row( $nxt_utility_query );

      $utility_data = array(
        'ut_utility_status' => $status,
        'ut_postponed_days' => $postponed_days,
        'ut_utillity_date' => $nxt_utility->next_pay_date,
      );


    } else {
      $utility_data = array(
        'ut_utility_status' => $status,
        'ut_postponed_days' => $postponed_days,
      );    
    }



      $update_status = $wpdb->update( $user_table,$utility_data,array( 'id' => $id ));



  	//insert
  	$utility_data=array(
      'utility_id'		=> $id,
      'ut_utility_status' => $status,
      'ut_postponed_days' => $postponed_days 
    );
  	$update_status = $wpdb->insert( $utility_details,$utility_data);

  die();
}
add_action( 'wp_ajax_utility_status','utility_status' );
add_action( 'wp_ajax_nopriv_utility_status','utility_status' );


//Select Members 
function searchMember(){
  global $wpdb;
  $data['success'] = 0;
  $user_table   = $wpdb->prefix.'chaos_members';
  $search_term  = $_POST['search_key'];
  $query        = "SELECT * FROM {$user_table} WHERE active = 1 AND name like '%${search_term}%'";

  if( $data['items'] = $wpdb->get_results( $query, ARRAY_A ) ) {
    $data['success'] = 1;  
  }
  echo json_encode($data);
  die();
}

add_action( 'wp_ajax_searchMember','searchMember' );
add_action( 'wp_ajax_nopriv_searchMember','searchMember' );



//member insert form
function ft_member_insert() {
  global $wpdb;
  $football         = $wpdb->prefix.'chaos_football_billing';
  $query            = "SELECT * FROM {$football} WHERE active = 1 and was_bulid='0'";
  $football_id      = $wpdb->get_row( $query, OBJECT);
  if($football_id) {
    $id=$football_id->id;
  }
  else {

    $football_data =  array( 
    'ft_member_name'  => $_POST['name'],
   );

    $wpdb->insert($football,$football_data);
    $id = $wpdb->insert_id;
  }
  

  $football_bill_no =  array(
        'member_id'                 => $_POST['member_id'],
        'ft_member_name'            => $_POST['name'],
        'ft_member_phone_number'    => $_POST['phone'],
        'ft_membership_no'          => $_POST['membership_no'],
        'ft_date'                   => $_POST['billing_date'],
        'ft_bill_no'                => 'INV'.$id,
   );


  $wpdb->update( $football , $football_bill_no ,array( 'id' => $id ));
  echo $member_id='INV'.$id;
  die();
}

add_action( 'wp_ajax_ft_member_insert','ft_member_insert' );
add_action( 'wp_ajax_nopriv_ft_member_insert','ft_member_insert' );

//
//Fetch Football Princing
//
function footballPricing(){
  global $wpdb;
  $data['success'] = 0;
  $user_table         = $wpdb->prefix.'chaos_bill_princing';
  $query              = "SELECT * FROM {$user_table} WHERE active = 1 order by id desc";
  $football_pricing   = $wpdb->get_row( $query, OBJECT);
  echo $football_pricing->p_football_hour_week;
  die();
}

add_action( 'wp_ajax_footballPricing','footballPricing' );
add_action( 'wp_ajax_nopriv_footballPricing','footballPricing' );


//Football Billing List

function football_listing(){
  include( get_template_directory().'/inc/admin/billing/ajax/listing-template/list_football_billing.php' );
  die();
}

add_action( 'wp_ajax_football_listing','football_listing' );
add_action( 'wp_ajax_nopriv_football_listing','football_listing' );



//
//For Gaming Insert
//
//member insert form
function gaming_member_insert() {
  global $wpdb;
  $gaming         = $wpdb->prefix.'chaos_gaming_billing';
  $query            = "SELECT * FROM {$gaming} WHERE active = 1 and was_bulid='0'";
  $gaming_id      = $wpdb->get_row( $query, OBJECT);
  if($gaming_id) {
    $id=$gaming_id->id;
  }
  else {

    $gaming_data =  array( 
    'gaming_member_name'  => $_POST['name'],
   );

    $wpdb->insert($gaming,$gaming_data);
    $id = $wpdb->insert_id;
  }
  

  $gaming_data_update =  array(
        'member_id'                 => $_POST['member_id'],
        'gaming_member_name'            => $_POST['name'],
        'gaming_member_phone_number'    => $_POST['phone'],
        'gaming_membership_no'          => $_POST['membership_no'],
        'gaming_date'                   => $_POST['billing_date'],
        'gaming_bill_no'                => 'INV'.$id,
   );


  $wpdb->update( $gaming , $gaming_data_update ,array( 'id' => $id ));
  echo $member_id='INV'.$id;
  die();
}

add_action( 'wp_ajax_gaming_member_insert','gaming_member_insert' );
add_action( 'wp_ajax_nopriv_gaming_member_insert','gaming_member_insert' );


//Gaming Pricing
function gamingPricing(){
  global $wpdb;
  $data['success'] = 0;
  $user_table         = $wpdb->prefix.'chaos_bill_princing';
  $query              = "SELECT * FROM {$user_table} WHERE active = 1 order by id desc";
  $football_pricing   = $wpdb->get_row( $query, OBJECT);
  echo $football_pricing->p_gaming_hour_week;
  die();
}

add_action( 'wp_ajax_gamingPricing','gamingPricing' );
add_action( 'wp_ajax_nopriv_gamingPricing','gamingPricing' );

//Gaming Listing

function gaming_listing(){
  include( get_template_directory().'/inc/admin/billing/ajax/listing-template/list_gaming_billing.php' );
  die();
}

add_action( 'wp_ajax_gaming_listing','gaming_listing' );
add_action( 'wp_ajax_nopriv_gaming_listing','gaming_listing' );


//<------------ Start Lazer Tag------>

function lazertag_member_insert() {
  global $wpdb;
  $lazertag         = $wpdb->prefix.'chaos_lazertag_billing';
  $query            = "SELECT * FROM {$lazertag} WHERE active = 1 and was_bulid='0'";
  $lazertag_id      = $wpdb->get_row( $query, OBJECT);
  if($lazertag_id) {
    $id=$lazertag_id->id;
  }
  else {

    $lazertag_data =  array( 
    'lazertag_member_name'  => $_POST['name'],
   );

    $wpdb->insert($lazertag,$lazertag_data);
    $id = $wpdb->insert_id;
  }
  

  $lazertag_data_update =  array(
        'member_id'                       => $_POST['member_id'],
        'lazertag_member_name'            => $_POST['name'],
        'lazertag_member_phone_number'    => $_POST['phone'],
        'lazertag_membership_no'          => $_POST['membership_no'],
        'lazertag_date'                   => $_POST['billing_date'],
        'lazertag_bill_no'                => 'INV'.$id,
   );


  $wpdb->update( $lazertag , $lazertag_data_update ,array( 'id' => $id ));
  echo $member_id='INV'.$id;
  die();
}

add_action( 'wp_ajax_lazertag_member_insert','lazertag_member_insert' );
add_action( 'wp_ajax_nopriv_lazertag_member_insert','lazertag_member_insert' );


//Gaming Pricing
function lazertagPricing(){
  global $wpdb;
  $data['success'] = 0;
  $price = $_POST['price'];
  $user_table         = $wpdb->prefix.'chaos_bill_princing';
  $query              = "SELECT * FROM {$user_table} WHERE active = 1 order by id desc";
  $football_pricing   = $wpdb->get_row( $query, OBJECT);
  if($price == 'slot'){
  echo $football_pricing->p_lasertag_head_week;
  }
  else if($price == 'hours'){
  echo $football_pricing->p_lasertag_hour_week;
  }
  else {  
  echo $football_pricing->p_lasertag_happyhours_week;
  }

  die();
}

add_action( 'wp_ajax_lazertagPricing','lazertagPricing' );
add_action( 'wp_ajax_nopriv_lazertagPricing','lazertagPricing' );

//lazer tag billing

function lazertag_listing(){
  include( get_template_directory().'/inc/admin/billing/ajax/listing-template/list_lazertag_billing.php' );
  die();
}

add_action( 'wp_ajax_lazertag_listing','lazertag_listing' );
add_action( 'wp_ajax_nopriv_lazertag_listing','lazertag_listing' );


/*----------- End Lazer Tag------------*/






?>