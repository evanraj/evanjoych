
//<------ Start Football Billing jQuery Functions---->

jQuery(document).ready(function () {


//<--- Start Date Picker---->
  jQuery('#billing_date,.football_bill_date,#gaming_billing_date,.gaming_bill_date,.lazertag_bill_date').datepicker({
        dateFormat: 'yy-mm-dd'
    });

//<--- End Date Picker---->
  

  //<---- Start new user --->
 

  jQuery('.new_user_a').on('click', function(){
    jQuery('.select2-container, .new_user_a').css('display', 'none');
    jQuery('.new_user, .old_user_a').css('display', 'inline-block');

    jQuery('.discount_per').text(0);
    jQuery('.discount').val(0);
    calculation(); 
  jQuery.ajax({
    method: "POST",
    url: frontendajax.ajaxurl,
    data: {
      action                           : 'ft_member_insert',
      member_id                        : '',
      name                             : '',
      phone                            : '',
      membership_no                    : '',
      billing_date                     : '',
    },
    success: function (data) {

    var bill =jQuery('#billing_no').val(data);
    var bill =jQuery('.billing_no_div').text(data);

    }
  });
  })

  //<---- End new user --->

//<---- Start New user --->
    jQuery('.old_user_a').on('click', function(){
    jQuery('.select2-container, .new_user_a').css('display', 'inline-block');
    jQuery('.new_user, .old_user_a').css('display', 'none');

    jQuery('.discount_per').text('10%');
    jQuery('.discount').val(10);
    calculation(); 
 
  })
    //<---- End Old user --->

 //<---- Start Search bar --->


  jQuery('#receipt_per_page,#member_name,#member_number, #football_bill_date,#bill_no,#bill_amt').on('change', function() {
         jQuery.ajax({
            method: "POST",
            url: frontendajax.ajaxurl,
            data: {
              action                                        : 'football_listing',
              receipt_per_page                              : jQuery('#receipt_per_page').val(),
              member_name                                   : jQuery('#member_name').val(),
              member_number                                 : jQuery('#member_number').val(),
              football_bill_date                            : jQuery('#football_bill_date').val(),
              bill_no                                       : jQuery('#bill_no').val(),
              bill_amt                                      : jQuery('#bill_amt').val(),

            },
            success: function (data) {
              jQuery('.football_listing').html(data);
            }
          });

  });

//F icon Search bar
  jQuery('.search_icons').on('click', function() {

      jQuery.ajax({
            method: "POST",
            url: frontendajax.ajaxurl,
            data: {
              action                                        : 'football_listing',
              receipt_per_page                              : jQuery('#receipt_per_page').val(),
              member_name                                   : jQuery('#member_name').val(),
              member_number                                 : jQuery('#member_number').val(),
              football_bill_date                            : jQuery('#football_bill_date').val(),
              bill_no                                       : jQuery('#bill_no').val(),
              bill_amt                                      : jQuery('#bill_amt').val(),

            },
            success: function (data) {
              jQuery('.football_listing').html(data);
            }
          });

  });
 //<---- End Search bar --->


  //<--- Start Delete Billling --->
  jQuery('.c-delete-football').live( "click", function() {
    if(confirm('Are you sure you want to delete this element?')){
      var data=jQuery(this).attr("data-id");
      window.location.replace('admin.php?page=view_football_billing&id='+data+'&action=delete');
    }

  });
   //<--- End Delete Billling --->


//Select 2 
    jQuery(".search_billing").select2({
            multiple: false,
            minimumInputLength: 1,
            allowClear: true,
            placeholder: "Search Member",

            ajax: {
                type: 'POST',
                url: frontendajax.ajaxurl,
                delay: 250,
                dataType: 'json',
                data: function(params) {
                    return {
                        action: 'searchMember', // search term
                        page: 1,
                        search_key: params.term,

                    };
                },
                processResults: function(data) {
                    var results = [];

                    return {
                        results: jQuery.map(data.items, function(obj) {
                            return { id: obj.id, name:obj.name, phone:obj.phone, membership_no:obj.membership_no};
                        })
                    };
                },
                cache: true,
            },
            initSelection: function (element, callback) {
                callback({ id: '-', name: 'Search Member' });
            },
            templateResult: formatCustomerNamea,
            templateSelection: formatCustomerNamea
    }).on('select2:select', function (e) {
      var phone         = jQuery('#phone_number').val(e.params.data.phone);
      var name          = jQuery('#old_member_name').val(e.params.data.name);
      var id            = e.params.data.id;
      var membership_no = jQuery('#member_no').val(e.params.data.membership_no);
      var date          = jQuery('#billing_date').val(); 

      

      jQuery.ajax({
        method: "POST",
        url: frontendajax.ajaxurl,
        data: {
          action                           : 'ft_member_insert',
          member_id                        : e.params.data.id,
          name                             : e.params.data.name,
          phone                            : e.params.data.phone,
          membership_no                    : e.params.data.membership_no,
          billing_date                     : date,

        },
        success: function (member_no) {

        var bill = jQuery('#billing_no').val(member_no);
        jQuery('.discount').val(10);
        jQuery('.discount_per').text('10%');
                
        }

      }); 
      jQuery('.discount').val(10);
      calculation();    

    }); 
    //<---- End Select2---->

//Call Calculation function when enter Hours

    jQuery('.no_of_player').on('change',function() {

    calculation();
  });
//<--- End Call Function --->


//<---- Start Print Function ---->

jQuery('#football_print').on('click', function() {
      var bill_no=jQuery('#bill_no').text();
      var datapass =  printajax.internalprint+'/football-print/?bill_no='+bill_no+'&action=football_print';

      // billing_list_single
      var thePopup = window.open( datapass, "Customer Listing","scrollbars=yes,menubar=0,location=0,top=50,left=300,height=500,width=750" );
        thePopup.print(); 
    });

jQuery.ajax({
            method: "POST",
            url: frontendajax.ajaxurl,
            data: {
              action                           : 'footballPricing',
            },
            success: function (data) {
              jQuery('.football').val(data);
              jQuery('.football_in').text(data);
            }
          });


//<---- End Print Function ---->

});
  


 function formatCustomerNamea (state) {
        if (!state.id) {
            return state.id;
        }
        var $state = jQuery(
        '<span>' +
          state.name +
        '</span>'
        );
        return $state;
    };

    function formatCustomerNameb (state) {
        if (!state.id) {
            return state.id;
        }
        var $state = jQuery(
        '<span>' +
          state.id +
        '</span>'
        );
        return $state;
    };
    function calculation() {


            var no_of_player = jQuery('.no_of_player').val();
           

            var bill =jQuery('.football').val();    
            var value = bill * no_of_player;
            jQuery('.total_value').text(value);
            jQuery('.total_value').val(value);
            var discount=jQuery('.discount').val();
            
            var after_discount=(value*discount)/100;           
            jQuery('.discount').text(after_discount);
            jQuery('.after_discount').val(after_discount);

            var final=value-after_discount;
            jQuery('.final_bill').text(final);
            jQuery('.final_bill').val(final);

    }

//<------ End Football Billing jQuery Functions---->


  //
  //<-- Start Gaming jQuery functions----->
  //


jQuery(document).ready(function () {

//<---Start Gaming select2--->

  jQuery(".search_gaming_billing").select2({
          multiple: false,
          minimumInputLength: 1,
          allowClear: true,
          placeholder: "Search Member",

          ajax: {
              type: 'POST',
              url: frontendajax.ajaxurl,
              delay: 250,
              dataType: 'json',
              data: function(params) {
                  return {
                      action: 'searchMember', // search term
                      page: 1,
                      search_key: params.term,

                  };
              },
              processResults: function(data) {
                  var results = [];

                  return {
                      results: jQuery.map(data.items, function(obj) {
                          return { id: obj.id, name:obj.name, phone:obj.phone, membership_no:obj.membership_no};
                      })
                  };
              },
              cache: true,
          },
          initSelection: function (element, callback) {
              callback({ id: '-', name: 'Search Member' });
          },
          templateResult: formatCustomerNamea,
          templateSelection: formatCustomerNamea
  }).on('select2:select', function (e) {

    var phone         = jQuery('#gaming_phone_number').val(e.params.data.phone);
    var name          = jQuery('#gaming_old_member_name').val(e.params.data.name);
    var id            = e.params.data.id;
    var membership_no = jQuery('#gaming_member_no').val(e.params.data.membership_no);
    var date          = jQuery('#gaming_billing_date').val(); 

    

    jQuery.ajax({
      method: "POST",
      url: frontendajax.ajaxurl,
      data: {
        action                           : 'gaming_member_insert',
        member_id                        : e.params.data.id,
        name                             : e.params.data.name,
        phone                            : e.params.data.phone,
        membership_no                    : e.params.data.membership_no,
        billing_date                     : date,

      },
      success: function (member_no) {

      var bill = jQuery('#gaming_billing_no').val(member_no);
      jQuery('.gaming_discount').val(10);
      jQuery('.gaming_discount_per').text('10%');
              
      }

    }); 
    jQuery('.gaming_discount').val(10);
    gaming_calculation();    

  }); 

    //<---End Gaming select2--->

     //<---- Start new user --->
 

  jQuery('.new_user_a_gaming').on('click', function(){
    jQuery('.select2-container, .new_user_a_gaming').css('display', 'none');
    jQuery('.gaming_new_user, .old_user_a_gaming').css('display', 'inline-block');

    jQuery('.gaming_discount_per').text(0);
    jQuery('.gaming_discount').val(0);
    gaming_calculation(); 
    jQuery.ajax({
      method: "POST",
      url: frontendajax.ajaxurl,
      data: {
        action                           : 'gaming_member_insert',
        member_id                        : '',
        name                             : '',
        phone                            : '',
        membership_no                    : '',
        billing_date                     : '',
      },
      success: function (data) {

        var bill =jQuery('#gaming_billing_no').val(data);
        var bill =jQuery('.gaming_billing_no_div').text(data);
        

      }
    });
  });

//<---- End new user --->

//<---- Start New user --->
  jQuery('.old_user_a_gaming').on('click', function(){

    jQuery('.select2-container, .new_user_a_gaming').css('display', 'inline-block');
    jQuery('.gaming_new_user, .old_user_a_gaming').css('display', 'none');

    jQuery('.gaming_discount_per').text('10%');
    jQuery('.gaming_discount').val(10);
    gaming_calculation(); 
 
  });
  //<---- End Old user --->


//<---- Start Search bar --->


  jQuery('#gaming_per_page,#gaming_member_name,#gaming_member_number, #gaming_bill_date,#gaming_bill_no,#gaming_bill_amt').on('change', function() {
         jQuery.ajax({
            method: "POST",
            url: frontendajax.ajaxurl,
            data: {
              action                                       : 'gaming_listing',
              gaming_per_page                              : jQuery('#gaming_per_page').val(),
              gaming_member_name                           : jQuery('#gaming_member_name').val(),
              gaming_member_number                         : jQuery('#gaming_member_number').val(),
              gaming_bill_date                             : jQuery('#gaming_bill_date').val(),
              gaming_bill_no                               : jQuery('#gaming_bill_no').val(),
              gaming_bill_amt                              : jQuery('#gaming_bill_amt').val(),

            },
            success: function (data) {
              jQuery('.gaming_listing').html(data);
            }
          });

  });

//F icon Search bargaming_per_page
  jQuery('.search_icons_gaming').on('click', function() {

    jQuery.ajax({
          method: "POST",
          url: frontendajax.ajaxurl,
          data: {
            action                                       : 'gaming_listing',
            gaming_per_page                              : jQuery('#gaming_per_page').val(),
            gaming_member_name                           : jQuery('#gaming_member_name').val(),
            gaming_member_number                         : jQuery('#gaming_member_number').val(),
            gaming_bill_date                             : jQuery('#gaming_bill_date').val(),
            gaming_bill_no                               : jQuery('#gaming_bill_no').val(),
            gaming_bill_amt                              : jQuery('#gaming_bill_amt').val(),

          },
          success: function (data) {
            jQuery('.gaming_listing').html(data);
          }
        });

  });
 ////<---- End Search bar --->

//<--- Start Delete Billling --->
  jQuery('.c-delete-gaming').live( "click", function() {
    if(confirm('Are you sure you want to delete this element?')){
      var data=jQuery(this).attr("data-id");
      window.location.replace('admin.php?page=view_gaming_billing&id='+data+'&action=delete');
    }

  });
   //<--- End Delete Billling --->


//Call Calculation function when enter Hours
  jQuery('.gaming_player,.gaming_hours').live('change',function() {

    gaming_row_calculation(jQuery(this).parent().parent().parent());
  });

  jQuery('.gaming_total_value').live('change',function() {
    gaming_calculation();
  })
//<--- End Call Function --->

//<---- Start Print Function ---->

jQuery('#gaming_print').on('click', function() {
  var bill_no   = jQuery('#gaming_bill_no').text();
  var id        = jQuery('#gaming_id').val();
  var datapass  =  printajax.internalprint+'/gaming-print/?bill_no='+bill_no+'&id='+id+'&action=gaming_print';

  // billing_list_single
  var thePopup = window.open( datapass, "Customer Listing","scrollbars=yes,menubar=0,location=0,top=50,left=300,height=500,width=750" );
    thePopup.print(); 
});

//<---- End Print Function ---->
//<--- Start Calling Gaming Pricing  ---->
  jQuery.ajax({
      method: "POST",
      url: frontendajax.ajaxurl,
      data: {
        action                           : 'gamingPricing',
      },
      success: function (price) {
         jQuery('.gaming').text(price);
         jQuery('.gaming').val(price);

      }
  });

//<--- End Calling Gaming Pricing  ---->

});


function gaming_row_calculation(selector = '') {
  var no_players = selector.find('.gaming_player').val();
  var no_hours = selector.find('.gaming_hours').val();
  var tot_price = no_players * no_hours;
  var price = jQuery('.gaming').val();
  var tot_bill = (price * tot_price);

  selector.find('.gaming_total_value').val(tot_bill).change();
}

function gaming_calculation() {
  var sub_tot = parseFloat(0); 
  jQuery('.gaming_total_value').each(function(){
    sub_tot = sub_tot + parseFloat(jQuery(this).val());
  });

  jQuery('.gaming_sub_tot').val(sub_tot);
  jQuery('.gaming_sub_tot').text(sub_tot);
  var discount = jQuery('.gaming_discount').val();
  var discount_value = (sub_tot * discount )/100;
  var final_total = sub_tot - discount_value;

  jQuery('.after_gaming_discount').val(discount_value);
  jQuery('.gaming_discount').text(discount_value);

  jQuery('.gaming_final_bill').val(final_total);
  jQuery('.gaming_final_bill').text(final_total);
 
}

//
//<-- End Gaming jQuery functions----->
//




//
//<-- Start Lazer Tag jQuery functions----->
//

//<----- Select 2 for lazer Tag------>
jQuery(document).ready(function () {

  jQuery(".search_lazertag_billing").select2({
    multiple: false,
    minimumInputLength: 1,
    allowClear: true,
    placeholder: "Search Member",

    ajax: {
        type: 'POST',
        url: frontendajax.ajaxurl,
        delay: 250,
        dataType: 'json',
        data: function(params) {
            return {
                action: 'searchMember', // search term
                page: 1,
                search_key: params.term,

            };
        },
        processResults: function(data) {
            var results = [];

            return {
                results: jQuery.map(data.items, function(obj) {
                    return { id: obj.id, name:obj.name, phone:obj.phone, membership_no:obj.membership_no};
                })
            };
        },
        cache: true,
    },
      initSelection: function (element, callback) {
          callback({ id: '-', name: 'Search Member' });
      },
      templateResult: formatCustomerNamea,
      templateSelection: formatCustomerNamea
  }).on('select2:select', function (e) {

    var phone         = jQuery('#lazertag_phone_number').val(e.params.data.phone);
    var name          = jQuery('#lazertag_old_member_name').val(e.params.data.name);
    var id            = e.params.data.id;
    var membership_no = jQuery('#lazertag_member_no').val(e.params.data.membership_no);
    var date          = jQuery('#lazertag_billing_date').val(); 

  

    jQuery.ajax({
      method: "POST",
      url: frontendajax.ajaxurl,
      data: {
        action                           : 'lazertag_member_insert',
        member_id                        : e.params.data.id,
        name                             : e.params.data.name,
        phone                            : e.params.data.phone,
        membership_no                    : e.params.data.membership_no,
        billing_date                     : date,

      },
      success: function (member_no) {

        var bill = jQuery('#lazertag_billing_no').val(member_no);
        jQuery('.lazertag_discount').val(10);
        jQuery('.lazertag_discount_per').text('10%');
              
      }

    }); 
    jQuery('.lazertag_discount').val(10);
    lazertag_calculation();

  });


    //<---- Start new user --->
 

  jQuery('.new_user_a_lazertag').on('click', function(){
    jQuery('.select2-container, .new_user_a_lazertag').css('display', 'none');
    jQuery('.lazertag_new_user, .old_user_a_lazertag').css('display', 'inline-block');

    jQuery('.lazertag_discount_per').text(0);
    jQuery('.lazertag_discount').val(0);
    lazertag_calculation(); 
    jQuery.ajax({
      method: "POST",
      url: frontendajax.ajaxurl,
      data: {
        action                           : 'lazertag_member_insert',
        member_id                        : '',
        name                             : '',
        phone                            : '',
        membership_no                    : '',
        billing_date                     : '',
      },
      success: function (data) {

        var bill =jQuery('#lazertag_billing_no').val(data);
        var bill =jQuery('.lazertag_billing_no_div').text(data);
        

      }
    });
  });

//<---- End new user --->

//<---- Start New user --->
  jQuery('.old_user_a_lazertag').on('click', function(){

    jQuery('.select2-container, .new_user_a_lazertag').css('display', 'inline-block');
    jQuery('.lazertag_new_user, .old_user_a_lazertag').css('display', 'none');

    jQuery('.lazertag_discount_per').text('10%');
    jQuery('.lazertag_discount').val(10);
    lazertag_calculation(); 
 
  });
//<---- End Old user --->

  jQuery.ajax({
    method: "POST",
    url: frontendajax.ajaxurl,
    dataType: 'json',
    data: {
      action                           : 'lazertagPricing',
      price                            : 'slot',
    },
    success: function (price) {
       jQuery('.lazertag').text(price);
       jQuery('.lazertag').val(price);

    }
  });

  jQuery.ajax({
    method: "POST",
    url: frontendajax.ajaxurl,
    dataType: 'json',
    data: {
      action                           : 'lazertagPricing',
      price                            : 'hours',
    },
    success: function (price) {
       jQuery('.lazertag_hour_price').text(price);
       jQuery('.lazertag_hour_price').val(price);

    }
  });

  jQuery.ajax({
    method: "POST",
    url: frontendajax.ajaxurl,
    dataType: 'json',
    data: {
      action                           : 'lazertagPricing',
      price                            : 'happyhours',
    },
    success: function (price) {
       var happy=jQuery('.lazertag_happyhours').val(price);
       var happy=jQuery('.lazertag_happyhours_div').text(price);
       console.log(happy);

    }
  });

//<-------- call calculation when clicking player and hour change----->

  jQuery('.lazertag_player,.lazertag_hours,.lazertag_happyhours').on('change',function() {

    lazertag_calculation();
      
  });

//<-------- End call calculation when clicking player and hour change----->

//<--- Display pricing in lazer tag form---->
  jQuery('.gametype').on('click',function(){
    var value = jQuery('input[name=gametype]:checked').val();
    if(value == 'hours'){
      jQuery('.lazertag_hour_price').css('display', 'inline-block');
      jQuery('.lazertag').css('display', 'none');
      jQuery('.team').css('display','inline-block');
      jQuery('.lazertag_player').css('display', 'none');
      jQuery('.lazertag_happyhours_div').css('display', 'none');
      jQuery('.lazertag_happyhours').css('display', 'none');
      jQuery('.lazertag_happyhours_name').css('display', 'none');
    }
    else{
      jQuery('.lazertag').css('display', 'inline-block');
      jQuery('.lazertag_hour_price').css('display', 'none');
      jQuery('.team').css('display','none');
      jQuery('.lazertag_player').css('display', 'inline-block');
      jQuery('.lazertag_happyhours').css('display', 'inline-block');
     
      jQuery('.lazertag_happyhours_name').css('display', 'inline-block');

    }

    lazertag_calculation();
  });

//<--- End disply pricing in lazer tag form---->
//<--- Display pricing in lazer tag form---->
  jQuery('.lazertag_happyhours').on('click',function(){
     if (jQuery('.lazertag_happyhours').is(":checked"))
      {
        jQuery('.lazertag_happyhours_div').css('display', 'inline-block');
        jQuery('.lazertag').css('display', 'none');
        

      } else {

      jQuery('.lazertag').css('display', 'inline-block');
      jQuery('.lazertag_happyhours_div').css('display', 'none');

      }
      lazertag_calculation();
    
  });

//<--- End disply pricing in lazer tag form---->
//<---- Start Search bar --->


  jQuery('#lazertag_per_page,#lazertag_member_name,#lazertag_member_number, #lazertag_bill_date,#lazertag_bill_no,#lazertag_bill_amt').on('change', function() {
     jQuery.ajax({
        method: "POST",
        url: frontendajax.ajaxurl,
        data: {
          action                                         : 'lazertag_listing',
          lazertag_per_page                              : jQuery('#lazertag_per_page').val(),
          lazertag_member_name                           : jQuery('#lazertag_member_name').val(),
          lazertag_member_number                         : jQuery('#lazertag_member_number').val(),
          lazertag_bill_date                             : jQuery('#lazertag_bill_date').val(),
          lazertag_bill_no                               : jQuery('#lazertag_bill_no').val(),
          lazertag_bill_amt                              : jQuery('#lazertag_bill_amt').val(),

        },
        success: function (data) {
          jQuery('.lazertag_listing_team').html(data);
        }
      });

  });

//  icon Search bar
  jQuery('.search_icons_lazertag').on('click', function() {

    jQuery.ajax({
        method: "POST",
        url: frontendajax.ajaxurl,
        data: {
          action                                         : 'lazertag_listing',
          lazertag_per_page                              : jQuery('#lazertag_per_page').val(),
          lazertag_member_name                           : jQuery('#lazertag_member_name').val(),
          lazertag_member_number                         : jQuery('#lazertag_member_number').val(),
          lazertag_bill_date                             : jQuery('#lazertag_bill_date').val(),
          lazertag_bill_no                               : jQuery('#lazertag_bill_no').val(),
          lazertag_bill_amt                              : jQuery('#lazertag_bill_amt').val(),

        },
        success: function (data) {
          jQuery('.lazertag_listing').html(data);
        }
      });

  });
 ////<---- End Search bar --->


//<--- Start Delete Billling --->
  jQuery('.c-delete-lazertag').live( "click", function() {
    if(confirm('Are you sure you want to delete this element?')){
      var data=jQuery(this).attr("data-id");
      window.location.replace('admin.php?page=view_lazertag_bill&id='+data+'&action=delete');
    }

  });

//Lazer Tag Print
jQuery('#lazertag_print').on('click', function() {
      var bill_no=jQuery('#lazertag_billing').text();
      var datapass =  printajax.internalprint+'/lazertag-print/?bill_no='+bill_no+'&action=lazertag_print';

      // billing_list_single
      var thePopup = window.open( datapass, "Customer Listing","scrollbars=yes,menubar=0,location=0,top=50,left=300,height=500,width=750" );
        thePopup.print(); 
    });

});

function lazertag_calculation() {

  var price_lazertag = jQuery('input[name=gametype]:checked').val();
  if( price_lazertag == 'hours'){
    var bill =jQuery('.lazertag_hour_price').val(); 
    var lazertag_player = 1;
  }
  else {
    if (jQuery('.lazertag_happyhours').is(":checked"))
      {
        var bill =jQuery('.lazertag_happyhours').val();
      }
      else {
        var bill =jQuery('.lazertag').val();    
      }
      var lazertag_player = jQuery('.lazertag_player').val();

  }
  var lazertag_hours  = jQuery('.lazertag_hours').val();
  var value           =   (lazertag_player *  lazertag_hours);   
  var bill_amount     = (value * bill); 
  jQuery('.lazertag_total_value').val(bill_amount);
  var discount        = jQuery('.lazertag_discount').val();
  var after_discount  = (bill_amount * discount)/100;
  jQuery('.lazertag_discount').text(after_discount);
  jQuery('.after_lazertag_discount').val(after_discount);
  var total           = bill_amount - after_discount;
  jQuery('.lazertag_final_bill').val(total);
  jQuery('.lazertag_final_bill').text(total);

}



    //<------- End Lazer Tag js-------->



