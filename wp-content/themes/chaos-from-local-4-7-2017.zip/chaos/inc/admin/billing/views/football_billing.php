<?php

date_default_timezone_set('Asia/Kolkata');
$date = date('Y-m-d');
global $wpdb;
$billing_table = $wpdb->prefix. 'chaos_football_billing';
if(isset($_POST['action']) AND $_POST['action'] == 'football_billing_submit'  ) {

	if(isset($_POST['member_no']) AND $_POST['member_no'] == ''){
		$membership_no  = 0; 
		$member_name    = $_POST['member_name'];

	}  else{

		$membership_no  = $_POST['member_no']; 
		$member_name    = $_POST['old_member_name'];

	} 

		$bill_no = $_POST['billing_no'];

		$insert_data	 = array (
			'ft_date'           			=> $_POST['billing_date'],
			'ft_member_name'    			=> $member_name,
			'ft_membership_no'    			=> $membership_no,
			'ft_member_phone_number'        => $_POST['phone_number'],
			'ft_total'        				=> $_POST['total_value'],
			'ft_no_of_hours'  				=> $_POST['player'],
			'ft_discount' 					=> $_POST['after_discount'],
			'ft_football_bill' 				=> $_POST['final_bill'],
			'was_bulid' 					=> 1,
			);  
		$wpdb->update($billing_table,$insert_data,array('ft_bill_no' => $bill_no));


		//Send mail to admin

		$emailid = 'sowmiya@ajnainfotech.com';
		$subject = 'Football Billing For '.$bill_no;
		$message = $member_name.' Paid '.$_POST['final_bill'].' Rupees';

		//Mail Function
		wp_mail( $emailid, $subject, $message );

		print('<script>window.location.href="admin.php?page=display_football&action=display_football&bill_no='.$bill_no.'"</script>');
				exit();



		
}
$update_data = false;
	if(isset($_POST['action']) AND $_POST['action'] == 'update_football_bill'  ) {

	
		$bill_no = $_POST['billing_no'];

		$insert_data	 = array (
			'ft_date'           			=> $_POST['billing_date'],
			'ft_member_name'    			=> $_POST['old_member_name'],
			'ft_membership_no'    			=> $_POST['member_no'],
			'ft_member_phone_number'        => $_POST['phone_number'],
			'ft_total'        				=> $_POST['total_value'],
			'ft_no_of_hours'  				=> $_POST['player'],
			'ft_discount' 					=> $_POST['after_discount'],
			'ft_football_bill' 				=> $_POST['final_bill'],
			'was_bulid' 					=> 1,
			);  
		$wpdb->update($billing_table,$insert_data,array('ft_bill_no' => $bill_no));


		$emailid = 'sowmiya@ajnainfotech.com';
		$subject = 'Updated In Football Billing For '.$bill_no;
		$message = $_POST['old_member_name'].' Paid '.$_POST['final_bill'].' Rupees';

		//Mail Function
		wp_mail( $emailid, $subject, $message );

		print('<script>window.location.href="admin.php?page=display_football&action=display_football&bill_no='.$bill_no.'"</script>');
				exit();
		
	}
	if(isset($_GET['action']) AND $_GET['action'] == 'update'  ) {

	$id  			= $_GET['id'];
	$query        	= "SELECT * FROM {$billing_table} WHERE active = 1 AND id ='$id'";
   	$update_data   	= $wpdb->get_row( $query, OBJECT ); 

	}


?>
<style>

.billing_in {
    font-size: 16px;
    font-family: Arial;
    padding: 1px;
    float;left;
    padding: 24px;
}
.billing {
	color: #000000;
	font-family: Arial;
	margin-bottom:5px;
}
.billing_name input {
    width: 300px;
    height: 30px;

}

 #distributor_id {
   	display: none;
}
.billing label{
	float:left;
}
.billing_details{
	margin-left: 160px;
}
.billing_name_left input{
	width: 300px;
    height: 30px;

}
.billing_name_left{
	
    margin-left: 71%;
    margin-top: -30px;
}
.billing_name{
	height: 40px;
}
.new_user, .old_user_a{
	display: none;
}

.old_user_a, .new_user_a {
	cursor: pointer;
}

</style>
<section class="add-billing">
	<div class="">
		<div class="text-center">
			<div class="col-md-6 title">
				<h1>Football Billing</h1>
			</div>
		</div>
		<form class="form-horizontal" action="" method="POST" id="billing_form">
			<div class="billing_details">
				<div>
					<div class="billing_name">
						<span class="billing" style="padding: 8px 28px;"><label>Date : </label></span>
						<span class="billing_in"><input type="text" name="billing_date" id="billing_date" value="<?php 
						if( $_GET['action'] == 'update') { 
							echo $update_data->ft_date;
						}
						else {
							echo $date; 
						}
						?>">
						</span>
					</div>
					<div class="billing_name_left">
						<span class="billing" style="padding: 8px 28px;"><label>Bill No : </label></span>
						<input type="text" name="billing_no" id="billing_no" class="billing_no" value="<?php echo $update_data->ft_bill_no; ?>" readonly>

					</div>
				</div>
				<div class="billing_name">
					<span class="billing" style="padding: 8px 12px;"><label>Billing Type </label></span>
					<span class="billing_in">Football Billing</span>
				</div>
				<div class="billing_name">
					<span class="billing" style="padding: 1px;"><label>Member Name:</label></span>
					<span class="billing_in">

					<?php 
						if($_GET['action']=='update') {

							echo '<input type="text" name="old_member_name" id="old_member_name" value="'.$update_data->ft_member_name.'" class="member_no">';

						} else{
						?>
						<select style="width: 300px;"  class="search_billing" name="search_billing" id="search_billing">
						</select>
						<input type="text" name="member_name" id="new_user" value="" class="new_user">
						<input type="hidden" name="member_no" id="member_no" value="" class="member_no">
						<input type="hidden" name="old_member_name" id="old_member_name" value="" class="old_member_name">
						<a class="new_user_a">New User</a>
						<a class="old_user_a">Old User</a>
						<?php } ?>
					</span>
				</div>
				<div class="billing_name">
					<span class="billing" style="padding: 2px;"><label>Phone Number </label></span>
					<span class="billing_in"><input type="text" name="phone_number"  id="phone_number" value="<?php echo $update_data->ft_member_phone_number; ?>"></span>
				</div>
			</div>			
			
			<div class=" ">
			  	<div data-repeater-list="" class="div-table">
				    <div class="div-table-row">
					    <div class="div-table-head sl-no">S.No</div>
					    <div class="div-table-head action">Hours</div>
					    <div class="div-table-head action">Value</div>
					    <div class="div-table-head action">Bill Amout</div>
					   
					</div>
			    	<div data-repeater-item class="repeterin div-table-row">
						<div class="div-table-col sale-rowno">
                            <div class="type-container">                               
                            </div>
                            <div class="rowno">1</div>
                        </div>
					     
					    <div class="div-table-col">
                            <div class="no_of_player_in player">
                            	<input type="text" name="player" id="player" value="<?php echo  $update_data ->ft_no_of_hours; ?>" class="no_of_player">
                            </div>
					    </div>
					    <div class="div-table-col">
                            <input type="hidden" name="football" id="football" class="football">
                            <div class="football_in player">
                            </div>
					    </div>
					    <div class="div-table-col">
					    <input type="hidden" name="total_value" id="total_value" class="total_value">
                           <div class="total_value" id="total_value">
                            	<?php 
                            	if(($_GET['action'])=='update'){
										echo $update_data ->ft_total;
								}
                            	?>
                            </div>
					    </div>  
			        </div>
			        <div data-repeater-item class="repeterin div-table-row">
						<div class="div-table-col sale-rowno">  </div>		                         			     
					    <div class="div-table-col"></div>                            	    
					    <div class="div-table-col"> Discount(<span id="discount_per" class="discount_per"></span>)</div>  
					    <div class="div-table-col">
					    	<input type="hidden" name="discount" id="discount" class="discount" value="<?php if($_GET['action'] == 'update' && $update_data->member_id != 0){
					    		echo 10;

					    		} else {
					    			echo 0;
					    			}
					    			?>"
					    			>
					    	<input type="hidden" name="after_discount" id="after_discount" class="after_discount" value="">
                           	<div class="discount" id="discount">
	                           	<?php 
	                            	if(($_GET['action'])=='update'){
		 								echo  $update_data ->ft_discount; 
		 								
									}else
									{
										echo 0;
									}
	                            ?>
                           	</div>                                                   
					    </div>  
			        </div>
			        <div data-repeater-item class="repeterin div-table-row">
						<div class="div-table-col sale-rowno">  </div>	                         				     
					    <div class="div-table-col"> </div>                           					    
					    <div class="div-table-col">Total </div>                           
					    <div class="div-table-col">
					    	<input type="hidden" name="final_bill" id="final_bill" class="final_bill" value="<?php $update_data ->ft_football_bill; ?>">
                           	<div class="final_bill" id="final_bill">
							<?php 
                            	if(($_GET['action'])=='update'){
	 								echo  $update_data ->ft_football_bill; 
								}else
								{
									echo 0;
								}
                            ?>
                           	</div>              	                           
					    </div>  
			        </div>
			    </div>
			</div>
			<?php if(($_GET['action']) == 'update'){ ?>


			<input type="hidden" name="action" id="" value="update_football_bill"></br>
			<input type="submit" name="submit" id="submit" class="player_add" class="submit" value="Update">
			<?php } else { ?>

			<input type="hidden" name="action" id="" value="football_billing_submit"></br>
			<input type="submit" name="submit" id="submit" class="player_add" class="submit" value="Submit">
			<?php } ?>

		</form>
	</div>
</section>