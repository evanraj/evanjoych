<?php
	global $wpdb;

 	$pricing_table 	= $wpdb->prefix.'chaos_bill_princing';
	if(isset($_POST['action']) AND $_POST['action'] =='pricing') {
   
   	$pricing_data = array(

   		'p_football_hour_week'   	 	=> $_POST['football_hour_week'],
   		'p_football_hour_weekend' 		=> $_POST['football_hour_weekend'],
   		'p_lasertag_head_week'   		=> $_POST['lazertag_head_week'],
   		'p_lasertag_head_weekend'	 	=> $_POST['lazertag_head_weekend'],
   		'p_lasertag_hour_week'   		=> $_POST['lazertag_hour_week'],
   		'p_lasertag_hour_weekend' 		=> $_POST['lazertag_hour_weekend'],
   		'p_lasertag_happyhours_week'   	=> $_POST['lazertag_happyhours_week'],
   		'p_lasertag_happyhours_weekend' => $_POST['lazertag_happyhours_weekend'],
   		'p_gaming_hour_week' 			=> $_POST['gaming_head_week'],
   		'p_gaming_hour_weekend'   		=> $_POST['gaming_head_weekend'],

    	);
   		$wpdb->insert( $pricing_table, $pricing_data );
   		$utility_id = $wpdb->insert_id;
   		// echo "<pre>";
    	// var_dump($pricing_data); die();
  

	}

		$data_query              = "SELECT * FROM $pricing_table WHERE active = 1 ORDER BY id DESC";
		$update_data = $wpdb->get_row($data_query, OBJECT);

?>
<style>
.price_setting{
	width:100%;
}
.price_setting_in{
	width:50%;
	margin:0 auto;
	margin-top: 70px;
}
label
{
	font-size: 20px;
}
.football_pricing_in div,.football_pricing_in_hour div{
	float: left;
	width: 300px;
}

.football_pricing{
	margin-top: 70px;
}
#lazertag_pricing{
	width: 200px;	
    margin-top: 140px;
}
.lazertag_pricing_in div{
	float: left;
}
.title{
	margin-left: -50px;
}
.submit_button{
	float: left;
    margin-left: -390px;
    margin-top: 30px;
}


</style>
<form class="form-horizontal" action="" method="POST" id="">
	<section class="price_setting">
		<div class="price_setting_in">
			<div>
				<div class="football_pricing">
						<h1 class="title">Foot Ball</h1>
					<div class="football_pricing_in">
						<div><label>Per Hour(week)</label></div>
						<div><input type="text" name="football_hour_week" id="football_hour_week" value="<?php echo $update_data->p_football_hour_week; ?>" /></div>
					</div>
				</div>
				<div class="football_pricing">
					<div class="football_pricing_in_hour">
						<div><label>Per Hour(weekend)</label></div>
						<div><input type="text" name="football_hour_weekend" id="football_hour_weekend" value="<?php echo $update_data->p_football_hour_weekend; ?>" /></div>
					</div>
				</div>
			</div>
			<div>
				<div class="football_pricing">
						<h1 style="width: 200px;margin-top: 140px;" class="title">Lazer Tag</h1>
					<div class="football_pricing_in">
						<div><label>Per Head/Per Game(week)</label></div>
						<div><input type="text" name="lazertag_head_week" id="lazertag_head_week" value="<?php echo $update_data->p_lasertag_head_week; ?>" /></div>
					</div>
				</div>
				<div class="football_pricing">
					<div class="football_pricing_in_hour">
						<div><label>Per Head/Per Game(weekend)</label></div>
						<div><input type="text" name="lazertag_head_weekend" id="lazertag_head_weekend" value="<?php echo $update_data->p_lasertag_head_weekend; ?>" /></div>
					</div>
				</div>
				<div class="football_pricing">
					<div class="football_pricing_in" style="margin-top: 120px;">
						<div><label>Per Hour(week)</label></div>
						<div><input type="text" name="lazertag_hour_week" id="lazertag_hour_week" value="<?php echo $update_data->p_lasertag_hour_week; ?>" /></div>
					</div>
				</div>
				<div class="football_pricing">
					<div class="football_pricing_in_hour" style="margin-top: 170px;">
						<div><label>Per Hour(weekend)</label></div>
						<div><input type="text" name="lazertag_hour_weekend" id="lazertag_hour_weekend" value="<?php echo $update_data->p_lasertag_hour_weekend; ?>" /></div>
					</div>
				</div>
				<div class="football_pricing">
						<h2 style="width: 200px;margin-top: 140px;font-size: 20px;" class="title">Happy Hours</h2>
					<div class="football_pricing_in">
						<div><label>Per Head/Per Game(week)</label></div>
						<div><input type="text" name="lazertag_happyhours_week" id="lazertag_happyhours_week" value="<?php echo $update_data->p_lasertag_happyhours_week; ?>" /></div>
					</div>
				</div>
				<div class="football_pricing">
					<div class="football_pricing_in_hour">
						<div><label>Per Head/Per Game(weekend)</label></div>
						<div><input type="text" name="lazertag_happyhours_weekend" id="lazertag_happyhours_weekend" value="<?php echo $update_data->p_lasertag_happyhours_weekend; ?>" /></div>
					</div>
				</div>
			</div>
			<div>
				<div class="football_pricing">
						<h1 style="width: 200px;margin-top: 148px;" class="title">Gaming</h1>
					<div class="football_pricing_in">
						<div><label>Per Head/Per Hour(week)</label></div>
						<div><input type="text" name="gaming_head_week" id="gaming_head_week" value="<?php echo $update_data->p_gaming_hour_week; ?>" /></div>
					</div>
				</div>
				<div class="football_pricing">
					<div class="football_pricing_in_hour">
						<div><label>Per Head/Per Hour(weekend)</label></div>
						<div><input type="text" name="gaming_head_weekend" id="gaming_head_weekend" value="<?php echo $update_data->p_gaming_hour_weekend; ?>" /></div>
					</div>
				</div>
			</div>	
				<input type="hidden" name="action" id="submit" value="pricing"></br>	
				<input type="submit" name="submit" id="submit" class="player_add submit_button" value="Update">
		</div>
		
	</section>
</form>