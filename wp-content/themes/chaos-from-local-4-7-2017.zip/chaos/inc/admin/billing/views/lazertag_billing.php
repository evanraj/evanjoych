<?php

date_default_timezone_set('Asia/Kolkata');
$date = date('Y-m-d');
global $wpdb;
$lazertag_billing 			= $wpdb->prefix. 'chaos_lazertag_billing';
if(isset($_POST['action']) AND $_POST['action'] == 'lazertag_billing_submit'  ) {


	if(isset($_POST['lazertag_member_no']) AND $_POST['lazertag_member_no'] == ''){
		$membership_no  = 0; 
		$member_name    = $_POST['member_name'];

	}  else {

		$membership_no  = $_POST['lazertag_member_no']; 
		$member_name    = $_POST['lazertag_old_member_name'];

	} 

	$happyhours = ( isset($_POST['lazertag_happyhours']) &&  $_POST['lazertag_happyhours']) ? 1 : 0 ;
			
		$bill_no = $_POST['lazertag_billing_no'];

		$insert_data	 = array (
			'lazertag_date'           				=> $_POST['lazertag_billing_date'],
			'lazertag_member_name'    				=> $member_name,
			'lazertag_membership_no'    			=> $membership_no,
			'lazertag_member_phone_number'        	=> $_POST['lazertag_phone_number'],
			'gametype'        						=> $_POST['gametype'],
			'lazertag_players'						=> $_POST['lazertag_player'],	
			'lazertag_hours'						=> $_POST['lazertag_hours'],
			'lazertag_happyhours'					=> $happyhours,
			'lazertag_total'						=> $_POST['lazertag_total_value'],
			'lazertag_discount' 					=> $_POST['after_lazertag_discount'],
			'lazertag_bill' 						=> $_POST['lazertag_final_bill'],
			'was_bulid' 							=> 1,
			);  

		$wpdb->update($lazertag_billing,$insert_data,array('lazertag_bill_no' => $bill_no));

		//Send mail to admin

		$emailid = 'sowmiya@ajnainfotech.com';
		$subject = 'Lazertag Billing For '.$bill_no;
		$message = $member_name.' Paid '.$_POST['lazertag_final_bill'].' Rupees';

		//Mail Function
		wp_mail( $emailid, $subject, $message );



	
		print('<script>window.location.href="admin.php?page=display_lazertag&action=display_lazertag&bill_no='.$bill_no.'"</script>');
				exit();
}
	$update_data = false;
 

	if(isset($_POST['action']) AND $_POST['action'] == 'update_lazertag_bill'  ) {


	if(isset($_POST['lazertag_member_no']) AND $_POST['lazertag_member_no'] == ''){
		$membership_no  = 0; 
		$member_name    = $_POST['member_name'];

	}  else {

		$membership_no  = $_POST['lazertag_member_no']; 
		$member_name    = $_POST['lazertag_old_member_name'];

	} 

	$happyhours = ( isset($_POST['lazertag_happyhours']) &&  $_POST['lazertag_happyhours']) ? 1 : 0 ;
			
		$bill_no = $_POST['lazertag_billing_no'];

		$insert_data	 = array (
			'lazertag_date'           				=> $_POST['lazertag_billing_date'],
			'lazertag_member_name'    				=> $_POST['lazertag_old_member_name'],
			'lazertag_membership_no'    			=> $membership_no,
			'lazertag_member_phone_number'        	=> $_POST['lazertag_phone_number'],
			'gametype'	       						=> $_POST['gametype'],
			'lazertag_players'						=> $_POST['lazertag_player'],	
			'lazertag_hours'						=> $_POST['lazertag_hours'],
			'lazertag_happyhours'					=> $happyhours,
			'lazertag_total'						=> $_POST['lazertag_total_value'],
			'lazertag_discount' 					=> $_POST['after_lazertag_discount'],
			'lazertag_bill' 						=> $_POST['lazertag_final_bill'],
			'was_bulid' 							=> 1,
			);  

		$wpdb->update($lazertag_billing,$insert_data,array('lazertag_bill_no' => $bill_no));

		//Send mail to admin

		$emailid = 'sowmiya@ajnainfotech.com';
		$subject = 'Updated in Lazertag Billing For '.$bill_no;
		$message = $member_name.' Paid '.$_POST['lazertag_final_bill'].' Rupees';

		//Mail Function
		wp_mail( $emailid, $subject, $message );

		

		
		print('<script>window.location.href="admin.php?page=display_lazertag&action=display_lazertag&bill_no='.$bill_no.'"</script>');
				exit();

	}

	if(isset($_GET['action']) AND $_GET['action'] == 'update'  ) {

	$id  			= $_GET['id'];
	$query        	= "SELECT * FROM {$lazertag_billing} WHERE active = 1 AND id ='$id'";
   	$update_data   	= $wpdb->get_row( $query, OBJECT );


	}


?>
<style>

.billing_in {
    font-size: 16px;
    font-family: Arial;
    padding: 1px;
    float;left;
    padding: 24px;
}
.billing {
	color: #000000;
	font-family: Arial;
	margin-bottom:5px;
}
.billing_name input {
    width: 300px;
    height: 30px;

}

 #distributor_id {
   	display: none;
}
.billing label{
	float:left;
}
.billing_details{
	margin-left: 160px;
}
.billing_name_left input{
	width: 300px;
    height: 30px;

}
.billing_name_left{
	
    margin-left: 71%;
    margin-top: -30px;
}
.billing_name{
	height: 40px;
}
.lazertag_new_user, .old_user_a_lazertag{
	display: none;
}

.old_user_a_lazertag, .new_user_a_lazertag {
	cursor: pointer;
}
.team{
	display: none;
	cursor: pointer;
}
.lazertag_hour_price,.lazertag_happyhours_div{
	display: none;
}

</style>
<section class="add-billing">
	<div class="">
		<div class="text-center">
			<div class="col-md-6 title">
				<h1>Lazertag Billing</h1>
			</div>
		</div>
		<form class="form-horizontal" action="" method="POST" id="billing_form">
			<div class="billing_details">
				<div>
					<div class="billing_name">
						<span class="billing" style="padding: 8px 28px;"><label>Date : </label></span>
						<span class="billing_in"><input type="text" name="lazertag_billing_date" id="lazertag_billing_date" value="<?php 
						if( $_GET['action'] == 'update') { 
							echo $update_data->lazertag_date;
						}
						else {
							echo $date; 
						}
						?>">
						</span>
					</div>
					<div class="billing_name_left">
						<span class="billing" style="padding: 8px 28px;"><label>Bill No : </label></span>
						<input type="text" name="lazertag_billing_no" id="lazertag_billing_no" class="lazertag_billing_no" value="<?php echo $update_data->lazertag_bill_no; ?>" readonly>

					</div>
				</div>
				<div class="billing_name">
					<span class="billing" style="padding: 8px 12px;"><label>Billing Type </label></span>
					<span class="billing_in">Lazertag Billing</span>
				</div>
				<div class="billing_name">
					<span class="billing" style="padding: 1px;"><label>Member Name:</label></span>
					<span class="billing_in">

					<?php 
						if($_GET['action']=='update') {

							echo '<input type="text" name="lazertag_old_member_name" id="lazertag_old_member_name" value="'.$update_data->lazertag_member_name.'" class="member_no">';

						} else{
						?>
						<select style="width: 300px;"  class="search_lazertag_billing" name="search_lazertag_billing" id="search_lazertag_billing">
						</select>
						<input type="text" name="member_name" id="lazertag_new_user" class="lazertag_new_user">
						<input type="hidden" name="lazertag_member_no" id="lazertag_member_no" class="lazertag_member_no">
						<input type="hidden" name="lazertag_old_member_name" id="lazertag_old_member_name" class="lazertag_old_member_name">
						<a class="new_user_a_lazertag">New User</a>
						<a class="old_user_a_lazertag">Old User</a>
						<?php } ?>
					</span>
				</div>
				<div class="billing_name">
					<span class="billing" style="padding: 2px;"><label>Phone Number </label></span>
					<span class="billing_in"><input type="text" name="lazertag_phone_number"  id="lazertag_phone_number" value="<?php echo $update_data->lazertag_member_phone_number; ?>"></span>
				</div>
				<div class="billing_name_in">
					<span class="billing" style="padding: 3px 9px;"><label>Game Type </label></span>
					<span class="billing_in">
					<?php 
					if($_GET['action'] == 'update')
					{ 
						$check = $update_data->gametype; 
					?>


						<input type="radio" name="gametype" class="gametype" value="hours" <?php if( $check == 'hours' ) { echo "checked"; } ?>/> Hours
  						<input type="radio" name="gametype" class="gametype" value="slot" <?php if( $check == 'slot' ) {  echo "checked"; } ?>/> Slot
  						<br>


						
				<?php } else { ?>
						<input type="radio" name="gametype" class="gametype" value="hours" > Hours
  						<input type="radio" name="gametype" class="gametype" value="slot" checked> Slot<br>

  						<?php 
  					}
  						?>
					</span>
				</div>
			</div>			
			
			<div class="group_team">
			  	<div data-repeater-list="group_team" class="div-table">
				    <div class="div-table-row">
					    <div class="div-table-head sl-no">S.No</div>   
					    <div class="div-table-head ">No of members/Team</div>
					    <div class="div-table-head ">Hours/Game</div>
					    <div class="div-table-head ">Value</div>
					    <div class="div-table-head action">Bill Amout</div>
					   
					</div>
			    	<div data-repeater-item class="div-table-row">
						<div class="div-table-col sale-rowno">
                            <div class="type-container">                               
                            </div>
                            <div class="rowno">1</div>
                        </div>
					     
					    <div class="div-table-col">
                            <div class="no_of_player player">
                            	<input type="text" name="lazertag_player" id="lazertag_player" class="lazertag_player" value="<?php echo $update_data->lazertag_players; ?>">
                            	<input type="text" name="team" id="team"  class="team" readonly value="1">
                            	
                            </div>
					    </div>
					    <div class="div-table-col">
                            <div class="hours player">
                            	<input type="text" name="lazertag_hours" id="lazertag_hours" class="lazertag_hours" value="<?php echo $update_data->lazertag_hours; ?>">
                            </div>
					    </div>
					    <div class="div-table-col">
					    <?php 
					    	if($_GET['action'] == 'update'){
					    		$happyhours = $update_data->lazertag_happyhours;
					    		$value = $update_data->lazertag_players;
					    		?>
							<span class="lazertag_happyhours_name" <?php if($happyhours == 1 || $value != 0){ ?> style="display:inline" <?php  } else { ?> style="display:none" <?php } ?> >Happy Hours</span>
					    	<input type="checkbox" 
					    	<?php 
					    		if($happyhours == 1 || $value != 0) {
					    	 		if($happyhours == 1) { 
					    	 ?>
					    	  		checked  
					    	  <?php } 
					    	 	} else { 
					    	 ?>
					    	  style="display:none";
					    	 <?php } 
					    	 ?>
					    	  name="lazertag_happyhours" id="lazertag_happyhours" class="lazertag_happyhours"  />
					    	<span  <?php if($happyhours == 1){ ?> style="display:inline" <?php  } else { ?> style="display:none" <?php } ?> class="lazertag_happyhours_div"></span>
					    	<input type="hidden" name="lazertag" id="lazertag" class="lazertag">
                            <span <?php if($happyhours != 1 && $value != 0){ ?> style="display:inline" <?php  } else { ?> style="display:none" <?php } ?> class="lazertag player">
                            </span>
                            <input type="hidden" name="lazertag_hour_price" id="lazertag_hour_price" class="lazertag_hour_price">
                            <div <?php if($value == 0){ ?> style="display:inline" <?php } else { ?> style="display:none" <?php } ?> class="lazertag_hour_price player" >
                            </div>


					    	<?php 
					    	}
					    	else {
					    	 ?>

					    	
					    	<span class="lazertag_happyhours_name">Happy Hours</span>
					    	<input type="checkbox" name="lazertag_happyhours" id="lazertag_happyhours" class="lazertag_happyhours">
						    <span class="lazertag_happyhours_div"> </span>
                            <input type="hidden" name="lazertag" id="lazertag" class="lazertag">
                            <span class="lazertag player">
                            </span>
                            <input type="hidden" name="lazertag_hour_price" id="lazertag_hour_price" class="lazertag_hour_price">
                            <div class="lazertag_hour_price player" >
                            </div>
                            <?php 

                        	}
					    	?>
					    </div>
					    <div class="div-table-col">
					    	<input type="text" name="lazertag_total_value" id="lazertag_total_value" class="lazertag_total_value" value="<?php echo $update_data->lazertag_total;?>" readonly />   
					    </div>  
			        </div>
			    </div>
		        <div class="div-table-row">
					<div class="div-table-col sale-rowno" style="width: 89px;">  </div>		                         			     
				    <div class="div-table-col" style="width: 414px;"></div>                            	    
				    <div class="div-table-col" style="width: 415px;"></div>                            	    
				    <div class="div-table-col" style="width: 336px;"> Discount(<span id="lazertag_discount_per" class="lazertag_discount_per"></span>)</div>  
				    <div class="div-table-col" style="width: 415px;">
				    	<input type="hidden" name="lazertag_discount" id="lazertag_discount" class="lazertag_discount" value="
				    	<?php if($_GET['action'] == 'update' && $update_data->member_id != 0){
				    		echo 10;

				    		} else {
				    			echo 0;
				    			}
				    			?>">
				    	<input type="hidden" name="after_lazertag_discount" id="after_lazertag_discount" class="after_lazertag_discount" value="<?php echo  $update_data ->lazertag_discount;  ?>">
                       	<div class="lazertag_discount" id="lazertag_discount">
                           	<?php if($_GET['action'] == 'update'){
									echo $update_data->lazertag_discount;
									}
									else {
										0;
									}
							 ?>
                       	</div>                                                   
				    </div>  
		        </div>
		        <div class="div-table-row">
					<div class="div-table-col sale-rowno" style="width: 89px;">  </div>	                         				     
				    <div class="div-table-col" style="width: 414px;"> </div>                           					    
				    <div class="div-table-col" style="width: 415px;"> </div>                           					    
				    <div class="div-table-col" style="width: 336px;">Total </div>                           
				    <div class="div-table-col" style="width: 415px;">
				    	<input type="hidden" name="lazertag_final_bill" id="lazertag_final_bill" class="lazertag_final_bill">
                       	<div class="lazertag_final_bill" id="lazertag_final_bill">
						<?php 
                        	if(($_GET['action'])=='update'){
 								echo  $update_data ->lazertag_bill; 
							}else
							{
								echo 0;
							}
                        ?>
                       	</div>              	                           
				    </div>  
		        </div>
			 </div>
				
			<?php if(($_GET['action']) == 'update'){ ?>


			<input type="hidden" name="action" id="" value="update_lazertag_bill"></br>
			<input type="submit" name="submit" id="submit" class="player_add" class="submit" value="Update">
			<?php } else { ?>

			<input type="hidden" name="action" id="" value="lazertag_billing_submit"></br>
			<input type="submit" name="submit" id="submit" class="player_add" class="submit" value="Submit">
			<?php } ?>

		</form>
	</div>
</section>