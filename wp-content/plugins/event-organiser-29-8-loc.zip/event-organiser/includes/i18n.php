<?php
/**
 * This file doesn't do anything.
 * It's only purpose is to list the strings that would otherwise be missed by
 * gettext parsers.
 */
/// TRANSLATORS: This is the description that of the plug-in that appears in the "Plugins" page.
__( "Creates a custom post type 'events' with features such as recurring events, venues, Google Maps, calendar views and events and venue pages", 'eventorganiser' );
